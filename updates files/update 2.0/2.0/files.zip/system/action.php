<?php
require('config_session.php');

if(isset($_POST['take_action'], $_POST['target'])){
	$action = escape($_POST['take_action']);
	$target = escape($_POST['target']);
	if($action == 'mute'){
		echo muteAccount($target);
		die();
	}
	else if($action == 'ban'){
		echo banAccount($target);
		die();
	}
	else if($action == 'unban'){
		echo unbanAccount($target);
		die();
	}
	else if($action == 'unmute'){
		echo unmuteAccount($target);
		die();
	}
	else if($action == 'verify_account'){
		echo verifyUser($target);
		die();
	}
	if($action == 'room_block'){
		echo blockRoom($target);
		die();
	}
	else if($action == 'room_mute'){
		echo muteRoom($target);
		die();
	}
	else if($action == 'room_unmute'){
		echo unmuteRoom($target);
		die();
	}
	else if($action == 'room_unblock'){
		echo unblockRoom($target);
		die();
	}
	else if($action == 'unkick'){
		echo unkickAccount($target);
		die();
	}
	else {
		echo 0;
		die();
	}
}
if(isset($_POST['check_kick'])){
	if($data['user_kick'] == 0){
		echo 1;
		die();
	}
}
if(isset($_POST['check_maintenance'])){
	if($data['maint_mode'] == 0){
		echo 1;
		die();
	}
}
if(isset($_POST['kick'], $_POST['reason'], $_POST['delay'])){
	$target = escape($_POST['kick']);
	$reason = escape($_POST['reason']);
	$delay = escape($_POST['delay']);
	echo kickAccount($target, $delay, $reason);
	die();
}
if(isset($_POST['take_room_action'], $_POST['target'])){
	$action = escape($_POST['take_room_action']);
	$target = escape($_POST['target']);
	if($action == 'room_unmute'){
		echo unmuteRoom($target);
		die();
	}
	else if($action == 'room_unblock'){
		echo unblockRoom($target);
		die();
	}
	else if($action == 'remove_admin'){
		echo removeRoomAdmin($target);
		die();
	}
	else if($action == 'remove_mod'){
		echo removeRoomMod($target);
		die();
	}
	else {
		echo 0;
		die();
	}
}
if(isset($_POST['remove_action'], $_POST['action_target'], $_POST['action_type']) && boomAllow(8)){
	$target = escape($_POST['action_target']);
	$type = escape($_POST['action_type']);
	$action = 0;
	switch($type){
		case 'muted':
			$action = unmuteAccount($target);
			break;
		case 'banned':
			$action = unbanAccount($target);
			break;
	}
	echo $action;
	die();
}
?>