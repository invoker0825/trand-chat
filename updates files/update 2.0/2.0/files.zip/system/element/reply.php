<div class="reply_item background_reply">
	<div class="reply_avatar get_info" data="<?php echo $boom['user_id']; ?>">
		<img src="<?php echo myavatar($boom['user_tumb']); ?>"/>
	</div>
	<div class="reply_content">
		<span class="inblock <?php echo $boom['user_color']; ?> text_small username"><?php echo $boom['user_name']; ?></span> <span class="text_xsmall no_break date"><?php echo displayDate($boom['reply_date']); ?></span>
		<div class="text_small vpad3">
		<?php echo boomPostIt($boom['reply_content']); ?>
		</div>
	</div>
</div>