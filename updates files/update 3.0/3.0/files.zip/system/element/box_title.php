<div class="box_title">
	<p><?php if($boom['icon'] != ''){ ?><i class="fa fa-<?php echo $boom['icon']; ?>"></i> <?php } ?><?php echo $boom['title']; ?></p>
</div>