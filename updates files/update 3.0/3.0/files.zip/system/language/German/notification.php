<?php
$nlang['like'] = 'Hat auf deinen Beiträge reagiert';
$nlang['reply'] = 'Hat deinen Beitrag kommentiert';
$nlang['add_post'] = 'Hat etwas an die Wand gehängt';
$nlang['accept_friend'] = 'Hat deine Freundschaftsanfrage angenommen';
$nlang['word_mute'] = 'Du wurdest wegen Beschimpfungen für %delay% Stumm gestellt';
$nlang['flood_mute'] = 'Du wurdest wegen Wiederholungen für %delay% Stumm gestellt';
$nlang['spam_mute'] = 'Du wurdest stumm geschaltet %delay% for spamming';
$nlang['rank_change'] = 'Dein Rang hat sich geändert, du bist jetzt ein anderer %rank%';
$nlang['mute'] = 'Du wurdest stummgeschaltet für %delay%';
$nlang['unmute'] = 'Du wurdest freigestellt';
$nlang['name_change'] = 'Hat deinen Benutzernamen geändert als %data%';
?>