<?php
$nlang['like'] = 'Ha reaccionado a una de tus publicaciones';
$nlang['reply'] = 'Comentó en una de tus publicaciones';
$nlang['add_post'] = 'Publicó algo en el muro';
$nlang['accept_friend'] = 'Aceptó tu solicitud de amistad';
$nlang['word_mute'] = 'Has sido silenciado %delay% por usar lenguaje ofensivo';
$nlang['flood_mute'] = 'Tu cuenta ha sido silenciada %delay% por haber llenado el chat de mensajes';
$nlang['spam_mute'] = 'Has sido silenciado %delay% por mandar mensajes no deseados';
$nlang['rank_change'] = 'Tu rango ha cambiado. Ahora eres %rank%';
$nlang['mute'] = 'Has sido silenciado %delay%';
$nlang['unmute'] = 'Has sido desilenciado';
$nlang['name_change'] = 'Has cambiado tu nombre de usuario a %data%';
?>