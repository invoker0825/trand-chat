<?php
/*
if you are not sure how those settings will affect the system please
do not edit you are reponsible of any change made to this file.
*/

$cody['max_reg'] = 5; 				// max registration per day per ip
$cody['max_room_name'] = 30; 		// max lenght of room name
$cody['max_description'] = 150; 		// max lenght of room description
$cody['act_time'] = 1;				// turn on off the innactivity balancer (0)off (1)on
$cody['max_room'] = 1;				// maximum room that a single user can create
$cody['reg_filter'] = 1;			// turn on off the ip registration filter (0)off (1)on
$cody['strict_guest'] = 1;			// strict guest registration mode follow system settings
$cody['max_verify'] = 3;			// maximum verification email allowed per 24 hours per user
$cody['max_report'] = 3;			// maximum active report allowed per users.
$cody['guest_per_day'] = 20;		// maximum guest account per day with same ip
$cody['guest_delay'] = 30;			// delay for wich a guest account cannot be overwrited in minutes
$cody['flood_delay'] = 15;			// minutes of mute applyed when a flood is detected
$cody['flood_limit'] = 6;			// post required within 10 sec to trigger flood protection
$cody['default_mute'] = 5;			// default mute delay in mute box
$cody['default_kick'] = 5;			// default kick delay in kick box
$cody['rbreak'] = 900;				// right chat panel mobile breakpoint in pixel
$cody['lbreak'] = 1260;				// left chat panel mobile breakpoint in pixel
$cody['right_size'] = 260;			// default right panel size in pixel
$cody['left_size'] = 150;			// default left panel size in pixel
$cody['color_count'] = 24;			// number of color used and defined in css
$cody['gradient_count'] = 24;		// number of gradient used and defined in css

$cody['can_word_filter'] = 10;		// rank required to not be affected by word filter
$cody['can_post_news'] = 11;		// rank required to post news
$cody['can_reply_news'] = 1;		// rank required to reply to news
$cody['can_invisible'] = 9;			// rank required to have invisibility option
$cody['can_modify_avatar'] = 8;		// rank required to modify users avatar
$cody['can_modify_cover'] = 8;		// rank required to modify users cover
$cody['can_modify_name'] = 9;		// rank required to modify users username
$cody['can_modify_mood'] = 8;		// rank required to modify users mood
$cody['can_modify_about'] = 8;		// rank required to modify users about me
$cody['can_modify_email'] = 10;		// rank required to modify users email
$cody['can_modify_color'] = 10;		// rank required to modify users color
$cody['can_modify_password'] = 10;	// rank required to modify users password
$cody['can_view_history'] = 8;		// rank required to view users action history
$cody['can_view_console'] = 10;		// rank required to access console in admin panel
$cody['can_view_email'] = 10;		// rank required to view users email
$cody['can_view_timezone'] = 10;	// rank required to view users timezone
$cody['can_view_id'] = 10;			// rank required to view users id
$cody['can_view_ip'] = 10;			// rank required to view users ip
$cody['can_room_pass'] = 8;			// rank required to enter room without pass
$cody['can_ban'] = 9;				// rank required to have ban power
$cody['can_kick'] = 8;				// rank required to have kick power

// cookie and session settings

define('BOOM_PREFIX', 'bc_');

// do not edit function below they are very important for the system to work properly

define('BOOM', 1);
define('BOOM_PATH', dirname(__DIR__));

define('BOOM_DHOST', $DB_HOST);
define('BOOM_DNAME', $DB_NAME);
define('BOOM_DUSER', $DB_USER);
define('BOOM_DPASS', $DB_PASS);
define('BOOM_CRYPT', $encryption);

function setBoomCookie($i, $p){
	setcookie(BOOM_PREFIX . "userid","$i",time()+ 31556926, '/');
	setcookie(BOOM_PREFIX . "utk","$p",time()+ 31556926, '/');
}
function unsetBoomCookie(){
	setcookie(BOOM_PREFIX . "userid","",time() - 1000, '/');
	setcookie(BOOM_PREFIX . "utk","",time() - 1000, '/');
}
function setBoomLang($val){
	setcookie(BOOM_PREFIX . "lang","$val",time()+ 31556926, '/');
}
function setBoomCookieLaw(){
	setcookie(BOOM_PREFIX . "claw","1",time()+ 31556926, '/');
}
?>