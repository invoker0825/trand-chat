<div class="sub_list_item" id="foundaction<?php echo $boom['user_id']; ?>">
	<div class="sub_list_avatar">
		<img class="admin_user<?php echo $boom['user_id']; ?>" src="<?php echo myavatar($boom['user_tumb']); ?>"/>
	</div>
	<div class="sub_list_name username <?php echo $boom['user_color']; ?>">
		<?php echo $boom['user_name']; ?>
	</div>
	<div onclick="removeUserAction(this, <?php echo $boom['user_id']; ?>, '<?php echo $boom['type']; ?>');" class="sub_list_option">
		<i class="fa fa-times edit_btn"></i>
	</div>
</div>