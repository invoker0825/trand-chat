<div class="ulist_item">
	<div class="ulist_avatar">
		<img class="lazyboom" src="" data-img="<?php echo myavatar($boom['user_tumb']); ?>"/>
	</div>
	<div class="ulist_name username <?php echo $boom['user_color']; ?>">
		<?php echo $boom['user_name']; ?>
	</div>
	<div class="ulist_option" onclick="removeIgnore(this, <?php echo $boom['user_id']; ?>);">
		<i class="fa fa-times"></i>
	</div>
</div>