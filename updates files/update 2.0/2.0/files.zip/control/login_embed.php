<div class="back_dark out_page_container">
	<div class="out_page_content">
		<div class="out_page_box">
			<div class="out_page_data pad_box">
				<div class="embed_logo_wrap">
					<img class="embed_logo" src="<?php echo getLogo('logo'); ?>"/>
				</div>
				<p class="bpad10"><?php echo $lang['left_welcome']; ?></p>
				<?php if(bridgeMode(0)){ ?>
				<button class="ok_btn large_button_rounded" onclick="getLogin();"><i class="fa fa-send"></i> <?php echo $lang['login']; ?></button>
				<?php } ?>
				<?php if(bridgeMode(1)){ ?>
				<button class="ok_btn large_button_rounded" onclick="bridgeLogin('<?php echo getChatPath(); ?>');"><i class="fa fa-user"></i> <?php echo $lang['enter_now']; ?></button>
				<?php } ?>
				<?php if(allowGuest()){ ?>
				<div class="clear"></div>
				<button class="theme_btn large_button_rounded" onclick="getGuestLogin();"><i class="fa fa-paw"></i> <?php echo $lang['guest_login']; ?></button>
				<?php } ?>
				<?php if(registration()){ ?>
				<div id="not_yet_member" class="login_not_member bclick">
					<p onclick="getRegistration();" class="inblock login_register_text pad10"><?php echo $lang['not_member']; ?></p>
				</div>
				<?php } ?>
				<p id="last_embed_title" class="sub_text"><?php echo $lang['last_active']; ?></p>
				<div id="last_embed">
					<?php echo embedActive(5); ?>
				</div>
				<div class="embed_lang bclick" onclick="getLanguage();">
					<img class="intro_lang" src="<?php echo $data['domain']; ?>/system/language/<?php echo $cur_lang; ?>/flag.png"/>
					<p><?php echo $lang['language']; ?></p>
				</div>			
			</div>
		</div>
		<?php if(bridgeMode(1)){ ?>
		<div onclick="getLogin();" class="adm_login bclick">
			<i class="fa fa-cog"></i> <?php echo $lang['login']; ?>
		</div>
		<?php } ?>
	</div>
</div>
<script data-cfasync="false" src="js/login.js<?php echo $bbfv; ?>"></script>