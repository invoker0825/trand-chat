<?php
/**
* Codychat
*
* @package Codychat
* @author www.boomcoding.com
* @copyright 2018
* @terms any use of this script without a legal license is prohibited
* all the content of Codychat is the propriety of BoomCoding and Cannot be 
* used for another project.
*/
require_once('../config_session.php');
?>
<?php if(allowRoom()){ ?>
<div class="pad5">
	<button class="reg_button theme_btn getbox" data-box="system/box/create_room.php" data-type="modal" id="chat_add_room">
		<i class="fa fa-plus"></i> <?php echo $lang['add_room']; ?>
	</button>
</div>
<?php } ?>
<div id="container_room">
	<?php echo getRoomList('list'); ?>
</div>