<div class="page_full vheight">
	<?php echo pageTitle($lang['privacy'], 'user-secret'); ?>
	<div class="page_element">
		<div class="pad15">
			<?php echo loadPageData('privacy_policy'); ?>
		</div>
	</div>
</div>