<div>
<?php echo str_replace('%user%', $data['user_name'], $lang['dear_user']); ?>
</div>
<br/>
<div>
<?php echo $lang['test_message']; ?>
</div>