<?php
$nlang['like'] = 'Reagiu a uma de suas postagens';
$nlang['reply'] = 'Comentei em uma de suas postagens';
$nlang['add_post'] = 'Postei algo na parede';
$nlang['accept_friend'] = 'Aceitou seu pedido de amizade';
$nlang['word_mute'] = 'Você foi silenciado %delay% usando Palavra ruim';
$nlang['flood_mute'] = 'Sua conta foi silenciada %delay% para inundação';
$nlang['spam_mute'] = 'Você foi silenciado %delay% para spam';
$nlang['rank_change'] = 'Sua classificação foi alterada, você está agora %rank%';
$nlang['mute'] = 'Você foi silenciado por %delay%';
$nlang['unmute'] = 'Você não foi silenciado';
$nlang['name_change'] = 'Mudou seu nome de usuário para %data%';
$nlang['prolike'] = 'Gostou do seu perfil';
$nlang['main_mute'] = 'Você foi silenciado no chat principal por %delay%';
$nlang['private_mute'] = 'Você foi silenciado em particular por %delay%';
$nlang['main_unmute'] = 'Você foi ativado no chat principal';
$nlang['private_unmute'] = 'Seu privado foi silenciado';
$nlang['gold_share'] = 'Compartilhou %data% Ouro com você';
$nlang['gift'] = 'Te enviou um presente';
$nlang['vipgift'] = 'Te enviou uma associação vip';
$nlang['vipsys'] = 'Uma associação vip foi adicionada à sua conta';
$nlang['custom'] = '%custom%';
?>