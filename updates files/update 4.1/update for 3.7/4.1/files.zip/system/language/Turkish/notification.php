<?php
$nlang['like'] = 'Paylaşımlarınızdan birine beğeni yapıldı.';
$nlang['reply'] = 'Paylaşımınıza yorum yapıldı';
$nlang['add_post'] = 'Arkadaş duvarınıza bir paylaşım yapıldı';
$nlang['accept_friend'] = 'Gönderdiğiniz arkadaşlık isteği kabul edildi.';
$nlang['word_mute'] = 'Sessizleştirildiniz %delay% kötü kelime nedeni ile.';
$nlang['flood_mute'] = 'Sessizleştirildiniz %delay% flod nedeni ile.';
$nlang['spam_mute'] = 'Sessizleştirildiniz %delay% spam mesaj nedeni ile.';
$nlang['rank_change'] = 'Seviyeniz değiştirildi. Yeni seviyeniz %rank%';
$nlang['mute'] = 'Sessizleştirildiniz %delay% ';
$nlang['unmute'] = 'Sessizlik engeliniz kaldırıldı.';
$nlang['name_change'] = 'Kullanıc adınız değiştrildi. Yeni kullanıcı adı %data%';
$nlang['prolike'] = 'Profilinizi beğendi';
$nlang['main_mute'] = 'Ana sohbette sessize alındınız %delay%';
$nlang['private_mute'] = 'Özel sohbet sessize alındınız %delay%';
$nlang['main_unmute'] = 'Ana sohbette sesiniz açıldı';
$nlang['private_unmute'] = 'Özel sohbette sesiniz açıldı';
$nlang['gold_share'] = 'Seninle %data% altın paylaştı';
$nlang['gift'] = 'sana bir hediye gönderdi';
$nlang['vipgift'] = 'Size bir VIP üyelik gönderdi';
$nlang['vipsys'] = 'Hesabınıza VIP üyelik eklendi';
$nlang['custom'] = '%custom%';
?>