<div class="page_full">
	<div class="page_element item_page_title">
		<p><?php if($boom['icon'] != ''){ ?><i class="fa fa-<?php echo $boom['icon']; ?>"></i> <?php } ?><?php echo $boom['title']; ?></p>
	</div>
</div>