<?php
$hlang['flood_mute'] = 'מציף הושתק';
$hlang['word_mute'] = 'מילה הושתקה';
$hlang['word_kick'] = 'מילה נזרקה';
$hlang['spam_mute'] = 'ספאם הושתק';
$hlang['spam_ban'] = 'סאפם נחסם';
$hlang['mute'] = 'השתקה';
$hlang['ban'] = 'חסימה';
$hlang['kick'] = 'לבעוט';
?>