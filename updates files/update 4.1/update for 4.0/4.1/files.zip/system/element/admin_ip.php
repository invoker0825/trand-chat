<div id="ipdel<?php echo $boom['id']; ?>" class="sub_list_item blisting ip_item">
	<div class="sub_list_content">
		<?php echo $boom['ip']; ?>
	</div>
	<div data="<?php echo $boom['id']; ?>" class="sub_list_option delete_ip">
		<i class="fa fa-times"></i>
	</div>
</div>