<?php
require('../config.php');
?>
<div class="pad_box text_box">
	<?php echo loadPageData('terms_of_use'); ?>
</div>