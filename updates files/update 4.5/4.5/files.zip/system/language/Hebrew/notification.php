<?php
$nlang['like'] = "הגיב לאחד מהפוסטים שלך";
$nlang['reply'] = "הגיב על אחד מהפוסטים שלך";
$nlang['add_post'] = "פרסם משהו על הקיר";
$nlang['accept_friend'] = "קיבל את בקשת החברות שלך";
$nlang['word_mute'] = "אתה הושתקת %delay% שימוש badword";
$nlang['flood_mute'] = "החשבון שלך הושבת %delay% על הצפה";
$nlang['spam_mute'] = "אתה הושתקת %delay% על הצפה";
$nlang['rank_change'] = "הדרגה שלך שונתה אתה עכשיו %rank%";
$nlang['mute'] = "הושתק בגלל %delay%";
$nlang['unmute'] = "הוסרה ההשתקה מימך";
$nlang['name_change'] = "שינה את השם שלך %data%";
$nlang['prolike'] = "אהב את הפרופיל שלך";
$nlang['main_mute'] = "התבצעה השתקה בצאט הראשי שלך למשך %delay%";
$nlang['private_mute'] = "התבצעה השתקה בצאט פרטי למשך %delay%";
$nlang['main_unmute'] = "התבטלה השתקה בצאט הראשי שלך";
$nlang['private_unmute'] = "התבטלה השתקה בצאט פרטי שלך";
$nlang['gold_share'] = "שיתף אתך %data% זהב";
$nlang['gift'] = "שלח לך מתנה";
$nlang['vipgift'] = "שלח לך חברות VIP";
$nlang['vipsys'] = "חברות VIP הוספה לחשבונך";
$nlang['custom'] = "%custom%";
?>