<div onclick="loadLanguage('<?php echo $boom; ?>');" class="list_element blisting btable lang_box">
	<div class="bcell_mid lang_flag_box">
		<img alt="<?php echo $boom; ?> flag" class="lazy lang_flag" data-src="system/language/<?php echo $boom; ?>/flag.png" src="<?php echo imgLoader(); ?>"/> 
	</div>
	<div class="bcell_mid lang_lang">
		<?php echo $boom; ?>
	</div>
</div>