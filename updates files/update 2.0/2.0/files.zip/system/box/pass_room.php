<?php
require_once('../config_session.php');

if(!isset($_POST['room_rank'], $_POST['room_id'])){
	die();
}
$ar = escape($_POST['room_rank']);
$rid = escape($_POST['room_id']);
if(!is_numeric($ar) || !is_numeric($rid)){
	die();
}
?>
<div class="pad15 centered_element">
	<div class="hpad15">
		<p class="vpad10"><?php echo $lang['enter_password']; ?></p>
		<input id="pass_input" class="full_input centered_element" type="password"/>
		<div class="tpad15">
			<button onclick="accessRoom(<?php echo $rid; ?>, <?php echo $ar; ?>);" id="access_room" class="reg_button button_half theme_btn"><i class="fa fa-check"></i> <?php echo $lang['ok']; ?></button>
			<button class="cancel_modal reg_button button_half default_btn"><?php echo $lang['cancel']; ?></button>
		</div>
	</div>
</div>