<?php
require_once('../config_session.php');
if(!isset($_POST['target'])){
	die();
}
$target = escape($_POST['target']);
$user = userDetails($target);

if(!canModifyColor($user)){
	echo 99;
	die();
}
?>
<div class="pad20">
	<div class="user_color" data-u="<?php echo $user['user_id']; ?>" data="<?php echo $user['user_color']; ?>">
		<?php if(canNameGrad()){ ?>
		<div class="reg_menu_container tmargin10">		
			<div class="reg_menu">
				<ul>
					<li class="reg_menu_item reg_selected" data="color_tab" data-z="reg_color"><?php echo $lang['color']; ?></li>
					<li class="reg_menu_item" data="color_tab" data-z="grad_color"><?php echo $lang['gradient']; ?></li>
				</ul>
			</div>
		</div>
		<?php } ?>
		<div id="color_tab">
			<div id="reg_color" class="reg_zone vpad5">
				<?php echo colorChoice($user['user_color'], 1); ?>
				<div class="clear"></div>
			</div>
			<?php if(canNameGrad()){ ?>
			<div id="grad_color" class="reg_zone vpad5 hide_zone">
				<?php echo gradChoice($user['user_color'], 1); ?>
				<div class="clear"></div>
			</div>
			<?php } ?>
		</div>
	</div>
	<div class="clear"></div>
	<div class="tpad5">
		<button class="cancel_over reg_button default_btn"><?php echo $lang['close']; ?></button>
	</div>
</div>