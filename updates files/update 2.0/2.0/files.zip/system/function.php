<?php
/**
* Codychat
*
* @package Codychat
* @author www.boomcoding.com
* @copyright 2018
* @terms any use of this script without a legal license is prohibited
* all the content of Codychat is the propriety of BoomCoding and Cannot be 
* used for another project.
*/
// shared function
function getIp(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $cloud =   @$_SERVER["HTTP_CF_CONNECTING_IP"];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($cloud, FILTER_VALIDATE_IP)) {
        $ip = $cloud;
    }
    else if(filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP)){
        $ip = $forward;
    }
    else{
        $ip = $remote;
    }
    return escape($ip);
}
function boomTemplate($getpage, $boom = '') {
	global $data, $lang, $mysqli, $boom_config;
    $page = __DIR__ . '/' . $getpage . '.php';
    $structure = '';
    ob_start();
    require($page);
    $structure = ob_get_contents();
    ob_end_clean();
    return $structure;
}
function calHour($h){
	return time() - ($h * 3600);
}
function calWeek($w){
	return time() - ( 3600 * 24 * 7 * $w);
}
function calmonth($m){
	return time() - ( 3600 * 24 * 30 * $m);
}
function calDay($d){
	return time() - ($d * 86400);
}
function calMinutes($min){
	return time() - ($min * 60);
}
function calHourUp($h){
	return time() + ($h * 3600);
}
function calWeekUp($w){
	return time() + ( 3600 * 24 * 7 * $w);
}
function calmonthUp($m){
	return time() + ( 3600 * 24 * 30 * $m);
}
function calDayUp($d){
	return time() + ($d * 86400);
}
function calMinutesUp($min){
	return time() + ($min * 60);
}
function myavatar($a){
	global $data;
	$path =  '/avatar/';
	if(stripos($a, 'default') !== false){
		$path =  '/default_images/';
	}
	if(linkAvatar($a)){
		return $a;
	}
	else {
		return $data['domain'] . $path . $a;
	}
}
function profileAvatar($a){
	global $data;
	$path =  '/avatar/';
	if(stripos($a, 'default') !== false){
		$path =  '/default_images/';
	}
	if(linkAvatar($a)){
		return 'href="' . $a . '" src="'. $a . '"';
	}
	else{
		return 'href="' . $data['domain'] . $path  . $a . '" src="' . $data['domain'] . $path  . $a . '"';
	}
}
function boomUserTheme($user){
	global $data;
	if($user['user_theme'] == 'system'){
		return $data['default_theme'];
	}
	else {
		return $user['user_theme'];
	}
}
function linkAvatar($a){
	if(preg_match('@^https?://@i', $a)){
		return true;
	}
}
function escape($t){
	global $mysqli;
	return $mysqli->real_escape_string(trim(htmlspecialchars($t, ENT_QUOTES)));
}
function boomSanitize($t){
	global $mysqli;
	$t = str_replace(array('\\', '/', '.', '<', '>', '%', '#'), '', $t);
	return $mysqli->real_escape_string(trim(htmlspecialchars($t, ENT_QUOTES)));
}
function softEscape($t){
	global $mysqli;
	$atags = '<a><p><h1><h2><h3><h4><img><b><strong><br><ul><li><div><i><span><u><th><td><tr><table><strike><small><ol><hr><font><center><blink><marquee>';
	$t = strip_tags($t, $atags);
	return $mysqli->real_escape_string(trim($t));
}
function systemReplace($text){
	global $lang;
	$text = str_replace('%bcquit%', $lang['leave_message'], $text);
	$text = str_replace('%bcjoin%', $lang['join_message'], $text);
	$text = str_replace('%bcclear%', $lang['clear_message'], $text);
	$text = str_replace('%spam%', $lang['spam_content'], $text);
	return $text;
}
function systemSpecial($content, $type, $delete = 1){
	global $data;
	$system = userDetails($data['system_id']);
	$template = array(
		'content'=> $content,
		'type'=> $type,
		'delete'=> $delete,
		'name'=> $system['user_name'],
		'avatar'=> $system['user_tumb'],
	);
	return boomTemplate('element/system_log', $template);
}
function userDetails($id){
	global $mysqli;
	$user = array();
	$getuser = $mysqli->query("SELECT * FROM boom_users WHERE user_id = '$id'");
	if($getuser->num_rows > 0){
		$user = $getuser->fetch_assoc();
	}
	return $user;
}
function ownAvatar($i){
	global $data;
	if($i == $data['user_id']){
		return 'glob_av';
	}
	return '';
}
function userPostChat($content, $snum = ''){
	global $mysqli, $data;
	$lact = calMinutes(3);
	$style = escape($data['bccolor'] . ' ' . $data['bcbold']);
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, snum, tcolor) VALUES ('" . time() . "', '{$data['user_id']}', '$content', '{$data['user_roomid']}', 'public', '$snum', '$style')");
	$last_id = $mysqli->insert_id;
	$mysqli->query("UPDATE boom_users SET caction = caction + 1 WHERE user_roomid = '{$data['user_roomid']}' and last_action > '$lact'");
	if($snum != ''){
		$user_post = array(
			'post_id'=> $last_id,
			'type'=> 'public',
			'post_date'=> time(),
			'tcolor'=> $style,
			'post_message'=> $content,
		);
		$post = array_merge($data, $user_post);
		if(!empty($post)){
			return createLog($data, $post);
		}
	}
}
function systemPostChat($room, $content){
	global $mysqli, $data;
	$lact = calMinutes(3);
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, tcolor) VALUES ('" . time() . "', '{$data['system_id']}', '$content', '$room', 'system', 'chat_system')");
	$mysqli->query("UPDATE boom_users SET caction = caction + 1 WHERE user_roomid = '$room' and last_action > '$lact'");	
	return true;
}
function botPostChat($id, $room, $content, $color = ''){
	global $mysqli, $data;
	$lact = calMinutes(3);
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, tcolor) VALUES ('" . time() . "', '$id', '$content', '$room', 'public', '$color')");
	$mysqli->query("UPDATE boom_users SET caction = caction + 1 WHERE user_roomid = '$room' and last_action > '$lact'");	
	return true;
}
function postPrivate($from, $to, $content, $snum = ''){
	global $mysqli, $data;
	$mysqli->query("INSERT INTO `boom_private` (time, target, hunter, message) VALUES ('" . time() . "', '$to', '$from', '$content')");
	$last_id = $mysqli->insert_id;
	if($to != $from){
		$mysqli->query("UPDATE boom_users SET pcount = pcount + 1 WHERE user_id = '$to'");
	}
	if($snum != ''){
		$user_post = array(
			'id'=> $last_id,
			'time'=> time(),
			'message'=> $content,
		);
		$post = array_merge($data, $user_post);
		if(!empty($post)){
			return privateLog($post, 1);
		}
	}
}
function systemNotify($user, $type, $custom, $custom2 = ''){
	global $mysqli, $data;
	$mysqli->query("INSERT INTO boom_notification ( notifier, notified, notify_type, notify_date, notify_source, notify_custom, notify_custom2) VALUE ('{$data['system_id']}', '$user', '$type', '" . time() . "', 'system', '$custom', '$custom2')");
	updateNotify($user);
}
function updateNotify($id){
	global $mysqli;
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_id = '$id'");
}
function updateDualNotify($id1, $id2){
	global $mysqli;
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_id = '$id1' OR user_id = '$id2'");
}
function updateGroupNotify($list){
	global $mysqli;
	if(empty($list)){
		return false;
	}
	$list = implode(", ", $list);
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_id IN ($list)");
}
function updateFriendsNotify($id){
	global $mysqli, $data;
	$list = listFriends($id);
	if(empty($list)){
		return false;
	}
	$list = implode(", ", $list);
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_id IN ($list)");
}
function updateStaffNotify(){
	global $mysqli;
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_rank > 7");
}
function updateAllNotify(){
	global $mysqli;
	$delay = calMinutes(5);
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_id > 0 AND last_action > '$delay'");
}
function isIgnored($id){
	global $boom_config;
	if(strpos($_SESSION[$boom_config['prefix'] . 'ignore'], 'u' . $id . 'x') !== false){
		return true;
	}
}
function processChatMsg($post) {
	global $data;
	if($post['user_id'] != $data['user_id'] && !preg_match('/http/',$post['post_message'])){
		$post['post_message'] = str_ireplace($data['user_name'], '<span class="my_notice">' . $data['user_name'] . '</span>', $post['post_message']);
	}
	return mb_convert_encoding(systemReplace($post['post_message']), 'UTF-8', 'auto');
}
function chatRank($rank, $id){
	global $data;
	if($id != $data['system_id'] && $data['ico'] == 2){
		$icon = systemRank($rank);
		if($icon != ''){
			return '<span class="chat_rank">' . $icon . '</span>';
		}
	}
}
function createLog($data, $post, $type = 0){
	global $lang;
	$avmenu = '';
	$log_options = '';
	$gender = '';
	if(isIgnored($post['user_id'])){
		return false;
	}
	if(notMe($post['user_id'])){
		$avmenu = 'onclick="openAvMenu(this, \''.$post['user_name'].'\','.$post['user_id'].','.$post['user_rank'].');"';
	}
	if(boomAllow(1)){
		if(boomAllow(8) || boomRole(4)){
			$log_options = '<div onclick="deleteLog(' . $post['post_id'] . ');" class="cclear"><i class="fa fa-times"></i></div>';
		}
		else if(!isSystem($post['user_id'])){
			$log_options = '<div onclick="openReport(' . $post['post_id'] . ', 1);" class="cclear"><i class="fa fa-flag"></i></div>';
		}
	}
	if($data['gender_ico'] > 1){
		$gender = 'avsex ' . sex($post['user_sex']) . ' ';
	}
	return  '<li id="log' . $post['post_id'] . '" data="' . $post['post_id'] . '" class="ch_logs ' . $post['type'] . '">
				<div class="chat_avatar" ' . $avmenu . '>
					<img class="' . $gender . ownAvatar($post['user_id']) . '" src="' . myavatar($post['user_tumb']) . '"/>
				</div>
				<div class="my_text">
					<div class="btable">
							<div class="cname">' . chatRank($post['user_rank'], $post['user_id']) . '<span class="username ' . $post['user_color'] . '">' . $post['user_name'] . '</span></div>
							<div class="cdate">' . chatDate($post['post_date']) . '</div>
							' . $log_options . '
					</div>
					<div class="chat_message ' . $post['tcolor'] . '">' . processChatMsg($post) . '</div>
				</div>
			</li>';	
}
function privateLog($post, $type){
	$message = systemReplace($post['message']);
	switch($type){
		case 1:
			return '<li id="priv' . $post['id'] . '">
						<div class="private_logs">
							<div class="private_avatar">
								<img data="' . $post['user_id'] . '" class="get_info avatar_private" src="' . myavatar($post['user_tumb']) . '"/>
							</div>
							<div class="private_content">
								<div class="hunter_private">' . $message . '</div>
								<p class="pdate">' . displayDate($post['time']) . '</p>
							</div>
						</div>
					</li>';
		case 2:
			return '<li id="priv' . $post['id'] . '">
						<div class="private_logs">
							<div class="private_content">
								<div class="target_private">' . $message . '</div>
								<p class="ptdate">' . displayDate($post['time']) . '</p>
							</div>
							<div class="private_avatar">
								<img data="' . $post['user_id'] . '" class="get_info avatar_private" src="' . myavatar($post['user_tumb']) . '"/>
							</div>
						</div>
					</li>';
	}
}
function createUserlist($list, $type = 1){
	global $data, $lang;
	if(!isVisible($list)){
		return false;
	}
	$icon = '';
	$flag = '';
	$status = '';
	$gender = '';
	if(useFlag($list['country'])){
		$flag = '<div class="user_item_flag"><img src="' . countryFlag($list['country']) . '"/></div>';
	}
	$offline = 'offline';
	$muted = lmIcon(mutedIcon($list), 'icmute');
	if($data['ico'] > 0){
		$icon = lmIcon(rankIcon($list,2), 'icrank');
	}
	if($data['gender_ico'] > 0){
		$gender = 'avsex ' . sex($list['user_sex']) . ' ';
	}
	if($list['last_action'] > getDelay() || isBot($list['user_bot'])){
		$offline = '';
		$status = getStatus($list['user_status'], 'ustatus');
	}
	return '<div onclick="dropUser(this,'.$list['user_id'].',\''.$list['user_name'].'\','.$list['user_rank'].','.$list['user_bot'].', ' . $type . ');" class="user_item ' . $offline . '">
				<div class="user_item_avatar"><img class="' . $gender . ownAvatar($list['user_id']) . '" src="' . myavatar($list['user_tumb']) . '"/> ' . $status . '</div>
				<div class="user_item_data"><p class="username ' . $list['user_color'] . '">' . $list["user_name"] . '</p>' . userState($list['user_mood']) . '</div>
				' . $muted . $icon . $flag . '
			</div>
			<div class="drop_list"></div>';
}
function lmIcon($t, $class = ''){
	if($t != ''){
		return '<div class="user_item_icon ' . $class . '">' . $t . '</div>';
	}
	else {
		return '';
	}
}
function chatDate($date){
	return date("j/m G:i", $date);
}
function displayDate($date){
	return date("j/m G:i", $date);
}
function longDate($date){
	return date("Y-m-d ", $date);
}
function longDateTime($date){
	return date("Y-m-d G:i ", $date);
}
function boomAllow($rank){
	global $data;
	if($data['user_rank'] >= $rank){
		return true;
	}
}
function boomRole($role){
	global $data;
	if($data['user_role'] >= $role){
		return true;
	}
}
function haveRole($role){
	if($role > 0){
		return true;
	}
}
function isGreater($rank){
	global $data;
	if($data['user_rank'] > $rank){
		return true;
	}
}
function notMe($id){
	global $data;
	if($id != $data['user_id']){
		return true;
	}
}
function isBot($user){
	if($user > 0){
		return true;
	}
}
function systemBot($user){
	if($user == 9){
		return true;
	}
}
function isSystem($id){
	global $data;
	if($id == $data['system_id']){
		return true;
	}
}
function getTopic(){
	global $mysqli, $lang, $data;
	$room_topic = '';
	$get_topic = $mysqli->query("SELECT topic FROM boom_rooms WHERE room_id = '{$data['user_roomid']}'");
	if($get_topic->num_rows > 0){
		$topic = $get_topic->fetch_assoc();
		if ($topic['topic'] != ''){
			$room_topic = $topic['topic'];
		}
	}
	return $room_topic;
}
function userConsole($target, $type, $custom = ''){
	global $mysqli, $data;
	$custom = escape($custom);
	$mysqli->query("INSERT INTO boom_console (hunter, target, room, ctype, custom, cdate) VALUES ('{$data['user_id']}', '$target', '{$data['user_roomid']}', '$type', '$custom', '" . time() . "')");
}
function selfConsole($type, $custom = ''){
	global $mysqli, $data;
	$exempt = array('create_room', 'delete_room');
	if(in_array($type, $exempt)){
		$data['user_roomid'] = 1;
	}	
	$custom = escape($custom);
	$mysqli->query("INSERT INTO boom_console (hunter, target, room, ctype, custom, cdate) VALUES ('{$data['user_id']}', '{$data['user_id']}', '{$data['user_roomid']}', '$type', '$custom', '" . time() . "')");
}
function systemConsole($target, $type, $custom = ''){
	global $mysqli, $data;
	$room = 0;
	if(isset($data['user_roomid'])){
		$room = $data['user_roomid'];
	}
	$custom = escape($custom);
	$mysqli->query("INSERT INTO boom_console (hunter, target, room, ctype, custom, cdate) VALUES ('{$data['system_id']}', '$target', '$room', '$type', '$custom', '" . time() . "')");
}
function muted(){
	global $data;
	if($data['user_mute'] > 0 || $data['user_temp_mute'] > 0 || $data['ureg_mute'] > 0){
		return true;
	}
}
function roomMuted(){
	global $data;
	if($data['room_mute'] > 0){
		return true;
	}
}
function joinRoom(){
	global $lang, $data;
	if(allowLogs() && isVisible($data)){
		$content = str_replace('%user%', $data['user_name'], $lang['system_join_room']);
		systemPostChat($data['user_roomid'], $content);
	}
}
function leaveRoom(){
	global $data, $lang;
	if(allowLogs()){
		if(isVisible($data) && $data['user_roomid'] != 0 && $data['last_action'] > time() - 30 ){
			$content = str_replace('%user%', $data['user_name'], $lang['quit_room']);
			systemPostChat($data['user_roomid'], $content);
		}
	}
}
function processUserData($t){
	global $data;
	return str_replace(array('%user%'), array($data['user_name']), $t);
}
function allowLogs(){
	global $data;
	if($data['allow_logs'] == 1){
		return true;
	}
}
function isVisible($user){
	if($user['user_status'] != 6){
		return true;
	}
}
function isGuest($rank){
	if($rank == 0){
		return true;
	}
}
function userDj($user){
	if($user['user_dj'] == 1){
		return true;
	}
}
function boomRecaptcha(){
	global $data;
	if($data['use_recapt'] > 0){
		return true;
	}
}
function encrypt($d){
	global $encryption;
	return sha1(str_rot13($d . $encryption));
}
function installEncrypt($d, $encr){
	return sha1(str_rot13($d . $encr));
}
function getDelay(){
	return time() - 35;
}
function muteDelay(){
	global $data;
	return calMinutesUp($data['mute_delay']);	
}
function kickDelay(){
	global $data;
	return calMinutesUp($data['kick_delay']);
}
function getMinutes($t){
	return $t / 60;
}
function userOwner($user){
	if($user['user_rank'] == 11){
		return true;
	}
}
function isStaff($rank){
	if($rank > 7){
		return true;
	}
}
function genKey(){
	return md5(rand(10000,99999) . rand(10000,99999));
}
function genCode(){
	return rand(111111,999999);
}
function genSnum(){
	global $data;
	return $data['user_id'] . rand(1111111, 9999999);
}
function canUpload(){
	global $data;
	if(boomAllow($data['allow_image'])){
		return true;
	}
}
function canPrivate(){
	global $data;
	if(boomAllow($data['allow_private'])){
		return true;
	}
}
function allowRoom(){
	global $data;
	if(boomAllow($data['allow_room'])){
		return true;
	}
}
function emoPlus(){
	global $data;
	if(boomAllow($data['emo_plus'])){
		return true;
	}
}
function allowGuest(){
	global $data;
	if($data['allow_guest'] == 1){
		return true;
	}
}
function canDirect(){
	global $data;
	if(boomAllow($data['allow_direct'])){
		return true;
	}
}
function canColor(){
	global $data;
	if(boomAllow($data['allow_colors'])){
		return true;
	}
}
function canGrad(){
	global $data;
	if(boomAllow($data['allow_grad'])){
		return true;
	}
}
function canNameColor(){
	global $data;
	if(boomAllow($data['allow_name_color'])){
		return true;
	}
}
function canNameGrad(){
	global $data;
	if(boomAllow($data['allow_name_grad'])){
		return true;
	}
}
function roomName(){
	global $mysqli, $data;
	$groom = $mysqli->query("SELECT room_name FROM boom_rooms WHERE room_id = '{$data['user_roomid']}'");
	$r = $groom->fetch_assoc();
	return $r['room_name'];
}
function wordUnmute($user){
	global $data, $mysqli;
	if($user['user_temp_mute'] < time() && $user['user_temp_mute'] > 0){
		$mysqli->query("UPDATE boom_users SET user_temp_mute = 0 WHERE user_id = '{$user['user_id']}'");
		clearMuteNotify($user['user_id']);
		systemNotify($user['user_id'], 'system_unmute', '');
	}
}
function regUnmute($d){
	global $data, $mysqli;
	$unmute = calMinutes($data['reg_mute']);
	if($d['ureg_mute'] <= $unmute){
		$mysqli->query("UPDATE boom_users SET ureg_mute = 0 WHERE user_id = '{$d['user_id']}'");
		clearMuteNotify($d['user_id']);
		systemNotify($d['user_id'], 'system_unmute', '');
	}
}
function boomMerge($a, $b){
	$c = $a . '_' . $b;
	return trim($c);
}
function clearMuteNotify($id){
	global $mysqli;
	usleep(100000);
	$mysqli->query("DELETE FROM boom_notification WHERE notified = '$id' AND notify_type IN ('bad_word', 'system_mute', 'system_unmute', 'flood_abuse')");
	usleep(100000);
}
function setToken(){
	global $boom_config;
	if(!empty($_SESSION[$boom_config['prefix'] . 'token'])){
		$_SESSION[$boom_config['prefix'] . 'token'] = $_SESSION[$boom_config['prefix'] . 'token'];
		return $_SESSION[$boom_config['prefix'] . 'token'];
	}
	else {
		$session = md5(rand(000000,999999));
		$_SESSION[$boom_config['prefix'] . 'token'] = $session;
		return $session;
	}
}
function checkToken() {
	global $boom_config;
    if (!isset($_POST['token']) || !isset($_SESSION[$boom_config['prefix'] . 'token']) || empty($_SESSION[$boom_config['prefix'] . 'token'])) {
        return false;
    }
	if($_POST['token'] == $_SESSION[$boom_config['prefix'] . 'token']){
		return true;
	}
    return false;
}
function userState($state){
	if(!empty($state)){
		return '<p class="text_xsmall bustate bellips">' . $state . '</p>';
	}
}
function isMuted($user){
	global $lang;
	if($user['user_mute'] > 0 || $user['user_temp_mute'] > 0 || $user['ureg_mute'] > 0){
		return true;
	}
}

// verified functions

function verifiedIcon($ver, $cl){
	global $data;
	if($ver == 1){
		return '<img class="' . $cl . '" src="' . $data['domain'] . '/default_images/badge/verified.png"/>';
	}
}

// ranking functions

function mutedIcon($user){
	global $lang;
	if($user['user_mute'] > 0 || $user['user_temp_mute'] > 0){
		return  '<i title="' . $lang['muted'] . '" class="fa fa-hand-paper-o mutx is_muted"></i>';
	}
	else if($user['room_mute'] == 1){
		return  '<i title="' . $lang['muted'] . '" class="fa fa-hand-paper-o mutx is_room_muted"></i>';
	}
	else if($user['ureg_mute'] > 0){
		return '<i title="' . $lang['muted'] . '" class="fa fa-plus-circle mutx theme_color"></i>';
	}
	else {
		return '';
	}
}

// sex and gender functions

function listGender($sex){
	global $lang;
	$list = '';
	$list .= '<option ' . selCurrent($sex, 1) . ' value="1">' . $lang['male'] . '</option>';
	$list .= '<option ' . selCurrent($sex, 2) . ' value="2">' . $lang['female'] . '</option>';
	$list .= '<option ' . selCurrent($sex, 3) . ' value="3">' . $lang['other'] . '</option>';
	return $list;
}
function validGender($sex){
	$gender = array(1,2,3);
	if(in_array($sex, $gender)){
		return true;
	}
}
function getGender($s){
	global $lang;
	switch($s){
		case 1:
			return $lang['male'];
		case 2:
			return $lang['female'];
		case 3:
			return $lang['other'];
		default:
			return $lang['not_set'];
	}
}
function sex($s){
	global $lang;
	switch($s){
		case 1:
			return 'boy';
		case 2:
			return 'girl';
		case 3:
			return 'nosex';
		default:
			return 'nosex';
	}
}

// status functions

function getStatus($status, $c){
	global $lang;
	switch($status){
		case 2:
			return curStatus($lang['away'], 'circle', 'absent', $c);
		case 3:
			return curStatus($lang['busy'], 'circle', 'gone', $c);
		default:
			return '';
	}
}
function curStatus($txt, $icon, $color, $c){
	return '<i title="' . $txt . '" class="fa ' . $color . ' fa-' . $icon . ' ' . $c . '"></i>';	
}
function listStatus($status){
	global $lang;
	switch($status){
		case 1:
			return statusMenu($lang['online'], 'circle', 'online');
		case 2:
			return statusMenu($lang['away'], 'circle', 'absent');
		case 3:
			return statusMenu($lang['busy'], 'circle', 'gone');
		case 6:
			return statusMenu($lang['invisible'], 'circle', 'invisible');
		default:
			return statusMenu($lang['online'], 'circle', 'online');
	}
}
function statusMenu($txt, $icon, $color){
	return '<div class="status_icon"><i class="fa ' . $color . ' fa-' . $icon . '"></i></div><div class="status_text">' . $txt . '</div>';
}
function listAllStatus(){
	global $lang, $data;
	$list = '';
	$list .= statusBox(1, listStatus(1));	
	$list .= statusBox(2, listStatus(2));
	$list .= statusBox(3, listStatus(3));
	if(boomAllow(9)){
		$list .= statusBox(6, listStatus(6));
	}
	return $list;
}
function statusBox($value, $content){
	return '<div class="status_option" data="' . $value . '">' . $content . '</div>';
}

// system ranking functions

function rankIcon($list, $type = 1){
	if(isBot($list['user_bot'])){
		return botRank();
	}
	else if(haveRole($list['user_role']) && !isStaff($list['user_rank']) && $type == 2){
		return roomRank($list['user_role']);
	}
	else {
		return systemRank($list['user_rank']);
	}
}
function botRank(){
	global $lang;
	return curRanking($lang['user_bot'], 'ico_bot', 'android');
}
function systemRank($rank){
	global $lang;
	switch($rank){
		case 2:
			return curRanking($lang['vip'], 'ico_vip', 'diamond');
		case 8:
			return curRanking($lang['mod'], 'ico_mod', 'shield');
		case 9:
			return curRanking($lang['admin'], 'ico_admin', 'star');
		case 10:
			return curRanking($lang['super_admin'], 'ico_sadmin', 'star');
		case 11:
			return curRanking($lang['owner'], 'ico_owner', 'trophy');
		default:
			return '';
	}
}
function roomRank($rank){
	global $lang;
	switch($rank){
		case 5:
			return curRanking($lang['r_admin'], 'ico_radmin', 'user');
		case 4:
			return curRanking($lang['r_mod'], 'ico_rmod', 'user');
	}
}
function curRanking($txt, $color, $icon){
	return '<i title="' . $txt . '" class="' . $color . ' fa fa-' . $icon . '"></i>';
}


function getRank($rank){
	global $lang;
	switch($rank){
		case 0:
			return $lang['guest'];
		case 1:
			return $lang['user'];
		case 2:
			return $lang['vip'];
		case 8:
			return $lang['mod'];
		case 9:
			return $lang['admin'];
		case 10:
			return $lang['super_admin'];
		case 11:
			return $lang['owner'];
		default:
			return $lang['user'];
	}
}
function roomTitle($rank){
	global $lang;
	switch($rank){
		case 5:
			return $lang['r_admin'];
		case 4:
			return $lang['r_mod'];
		case 0:
			return $lang['user'];
		default:
			return $lang['user'];
	}
}
function listRank($current, $req = 0){
	global $lang, $data;
	$rank = '';
	if($req == 1){
		$rank .= '<option value="0" ' . selCurrent($current, 0) . '>' . $lang['guest'] . '</option>';
	}
	$rank .= '<option value="1" ' . selCurrent($current, 1) . '>' . $lang['user'] . '</option>';
	$rank .= '<option value="2" ' . selCurrent($current, 2) . '>' . $lang['vip'] . '</option>';
	$rank .= '<option value="8" ' . selCurrent($current, 8) . '>' . $lang['mod'] . '</option>';
	$rank .= '<option value="9" ' . selCurrent($current, 9) . '>' . $lang['admin'] . '</option>';
	$rank .= '<option value="10" ' . selCurrent($current, 10) . '>' . $lang['super_admin'] . '</option>';
	$rank .= '<option value="11" ' . selCurrent($current, 11) . '>' . $lang['owner'] . '</option>';
	return $rank;
}
function changeRank($current){
	global $lang, $data;
	$rank = '';
	if(boomAllow(9)){
		$rank .= '<option value="1" ' . selCurrent($current, 1) . '>' . $lang['user'] . '</option>';
		$rank .= '<option value="2" ' . selCurrent($current, 2) . '>' . $lang['vip'] . '</option>';
		$rank .= '<option value="8" ' . selCurrent($current, 8) . '>' . $lang['mod'] . '</option>';
	}
	if(boomAllow(10)){
		$rank .= '<option value="9" ' . selCurrent($current, 9) . '>' . $lang['admin'] . '</option>';
	}
	if(boomAllow(11)){
		$rank .= '<option value="10" ' . selCurrent($current, 10) . '>' . $lang['super_admin'] . '</option>';
	}
	return $rank;
}
function roomRanking($rank = 0){
	global $lang;
	$room_menu = '<option value="0" ' . selCurrent($rank, 0) . '>' . $lang['public'] . '</option>';
	if(boomAllow(1)){
		$room_menu .= '<option value="1" ' . selCurrent($rank, 1) . '>' . $lang['user'] . '</option>';
	}
	if(boomAllow(2)){ 
		$room_menu .= '<option value="2" ' . selCurrent($rank, 2) . '>' . $lang['vip'] . '</option>';
	}
	if(boomAllow(8)){ 
		$room_menu .= '<option value="8" ' . selCurrent($rank, 8) . '>' . $lang['staff'] . '</option>';
	}
	return $room_menu;
}
function changeRoomRank($current){
	global $lang, $data;
	$rank = '';
	if(boomAllow(9) || boomRole(5)){
		$rank .= '<option value="0" ' . selCurrent($current, 0) . '>' . $lang['none'] . '</option>';
		$rank .= '<option value="4" ' . selCurrent($current, 4) . '>' . $lang['r_mod'] . '</option>';
	}
	if(boomAllow(9)){
		$rank .= '<option value="5" ' . selCurrent($current, 5) . '>' . $lang['r_admin'] . '</option>';
	}
	return $rank;
}

// room access ranking functions

function roomAccess($type){
	switch($type){
		case 0:
			return roomAccessIcon('globe', 'ico_public');
		case 1:
			return roomAccessIcon('user', 'ico_user');
		case 2:
			return roomAccessIcon('diamond', 'ico_vip');
		case 8:
			return roomAccessIcon('star', 'ico_admin');
		default:
			return roomAccessIcon('globe', 'ico_public');
	}
}
function roomAccessIcon($icon, $color){
	return '<i class="fa fa-' . $icon . ' ' . $color . '"></i>';	
}
?>