<option <?php echo selCurrent($boom, 1); ?> value="1">1 <?php echo $lang['minutes']; ?></option>
<option <?php echo selCurrent($boom, 2); ?> value="2">2 <?php echo $lang['minutes']; ?></option>
<option <?php echo selCurrent($boom, 5); ?> value="5">5 <?php echo $lang['minutes']; ?></option>
<option <?php echo selCurrent($boom, 10); ?> value="10">10 <?php echo $lang['minutes']; ?></option>
<option <?php echo selCurrent($boom, 15); ?> value="15">15 <?php echo $lang['minutes']; ?></option>
<option <?php echo selCurrent($boom, 30); ?> value="30">30 <?php echo $lang['minutes']; ?></option>
<option <?php echo selCurrent($boom, 60); ?> value="60">1 <?php echo $lang['hour']; ?></option>
<?php if(boomAllow(9)){ ?>
<option <?php echo selCurrent($boom, 360); ?> value="360">6 <?php echo $lang['hours']; ?></option>
<option <?php echo selCurrent($boom, 720); ?> value="720">12 <?php echo $lang['hours']; ?></option>
<option <?php echo selCurrent($boom, 1440); ?> value="1440">24 <?php echo $lang['hours']; ?></option>
<option <?php echo selCurrent($boom, 2880); ?> value="2880">48 <?php echo $lang['hours']; ?></option>
<option <?php echo selCurrent($boom, 4320); ?> value="4320">72 <?php echo $lang['hours']; ?></option>
<?php } ?>