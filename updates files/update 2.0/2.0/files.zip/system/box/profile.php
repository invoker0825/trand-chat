<?php
require('../config_session.php');

if(!isset($_POST['get_profile'], $_POST['cp'])){
	die();
}
$id = escape($_POST['get_profile']);
$cur_page = escape($_POST['cp']);
$user = userRoomDetails($id);
if(empty($user)){
	echo 2;
	die();
}
?>
<div class="modal_wrap_top modal_top">
	<div class="btable profile_top">
		<div id="proav" class="profile_avatar" data="<?php echo $user['user_tumb']; ?>" >
			<div class="avatar_spin">
				<img class="fancybox avatar_profile" <?php echo profileAvatar($user['user_tumb']); ?>/>
			</div>
		</div>
		<div class="profile_tinfo">
			<div class="pro_rank sub_dark">
				<?php echo verifiedIcon($user['verified'], 'pro_verified'); ?> 
				<?php echo systemRank($user['user_rank']); ?>
				<?php echo mutedIcon($user); ?>
				<?php echo getRank($user['user_rank']); ?>
			</div>
			<div class="pdetails_text pro_name">
				<?php echo $user['user_name']; ?>
			</div>
			<?php if(!empty($user['user_mood'])){ ?>
			<div class="pro_mood pro_mood sub_dark bellips">
				<?php echo $user['user_mood']; ?>
			</div>
			<?php } ?>
			<div class="pro_action">
				<?php if($user['my_friend'] == 0 && !isBot($user['user_bot']) && notMe($user['user_id']) && !isGuest($user['user_rank']) && boomAllow(1) && $user['ignored'] == 0 ){ ?>
					<button id="profriend" onclick="addFriend(this, <?php echo $user['user_id']; ?>);" class="tiny_button ok_btn "><i class="fa fa-user-plus"></i> <span class="hide_phone"><?php echo $lang['add_friend']; ?></span></button>
				<?php } ?>
				<?php if(!isBot($user['user_bot']) && notMe($user['user_id']) && $user['ignored'] == 0 && !isStaff($user['user_rank'])){ ?>
					<button id="proignore" onclick="ignoreUser(this, <?php echo $user['user_id']; ?>);" class="tiny_button delete_btn "><i class="fa fa-ban"></i> <span class="hide_phone"><?php echo $lang['ignore']; ?></span></button>
				<?php } ?>
			</div>
		</div>
	</div>
	<div class="cancel_modal profile_close">
		<i class="fa fa-times"></i>
	</div>
</div>
<div class="modal_menu">
	<ul>
		<li class="modal_menu_item modal_selected" data="profile_info"><?php echo $lang['about_me']; ?></li>
		<?php if(!isGuest($user['user_rank']) && !isBot($user['user_bot'])){ ?>
		<li class="modal_menu_item" onclick="lazyboom('profile_friends');" data="profile_friends"><?php echo $lang['friends']; ?></li>
		<?php } ?>
		<?php if(!isBot($user['user_bot']) && (( canRoomAction($user) || canEditUser($user, 8)) || canEditUser($user, 8)) ){ ?>
		<li class="modal_menu_item" data="main_actions"><?php echo $lang['do_action']; ?></li>
		<?php } ?>
		<?php if(boomAllow(0) && !isBot($user['user_bot'])){ ?> 
		<li class="modal_menu_item" data="prodetails"><?php echo $lang['main_info']; ?></li>
		<?php } ?>
		<?php if(canEditUser($user, 9)){ ?>
		<li class="modal_menu_item" data="void" onclick="editUser(<?php echo $user['user_id']; ?>);"><?php echo $lang['edit']; ?></li>
		<?php } ?>
	</ul>
</div>
<div class="pro_zone">
	<div class="modal_zone pad25 tpad15" id="profile_info">
		<?php if(boomAge($user['user_age'])){ ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['age']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo getUserAge($user['user_age']); ?></p>
		</div>
		<?php } ?>
		<?php if(boomSex($user['user_sex'])){ ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['gender']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo getGender($user['user_sex']); ?></p>
		</div>
		<?php } ?>
		<?php if(usercountry($user['country'])){ ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['country']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo countryName($user['country']); ?></p>
		</div>
		<?php } ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['join_chat']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo longDate($user['user_join']); ?></p>
		</div>
		<?php if($user['user_about'] != ''){ ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['about_me']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo $user['user_about']; ?></p>
		</div>
		<?php } ?>
	</div>
	<?php if(!isBot($user['user_bot'])){ ?>
	<div class="hide_zone  pad25 tpad15 modal_zone" id="prodetails">
		<?php if(isVisible($user)){ ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['last_seen']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo longDateTime($user['last_action']); ?></p>
		</div>
		<?php } ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['language']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo $user['user_language']; ?></p>
		</div>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['user_timezone']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo $user['user_timezone']; ?></p>
		</div>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['user_theme']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo boomUserTheme($user); ?></p>
		</div>
		<?php if(boomAllow(10) && !isBot($user['user_bot'])){ ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['email']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo $user['user_email']; ?></p>
		</div>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['ip']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo $user['user_ip']; ?></p>
		</div>
		<?php } ?>
		<?php if(boomAllow(8) && isGreater($user['user_rank']) || boomAllow(11)){ ?>
		<div class="listing_element info_pro">
			<p class="pro_title"><?php echo $lang['other_account']; ?></p>
			<p class="sub_text text_small pro_text"><?php echo sameAccount($user); ?></p>
		</div>
		<?php } ?>
	</div>
	<?php } ?>
	<?php if(!isGuest($user['user_rank']) && !isBot($user['user_bot'])){ ?>
	<div class="hide_zone pad20 modal_zone" id="profile_friends">
		<?php echo findFriend($user); ?>
		<div class="clear"></div>
	</div>
	<?php } ?>
	<?php if(!isBot($user['user_bot']) && (( canRoomAction($user) || canEditUser($user, 8)) || canEditUser($user, 8)) ){ ?>
	<div class="hide_zone modal_zone pad25" id="main_actions">
		<?php if(canEditUser($user, 8)){ ?>
		<div class="main_act_list">
			<p class="text_med bold"><?php echo $lang['main_action']; ?></p>
			<div class="setting_element">
				<p class="label"><?php echo $lang['do_action']; ?></p>
				<select id="set_user_action" onchange="takeAction(this, <?php echo $user['user_id']; ?>);">
					<?php echo listAction($user); ?>
				</select>
			</div>
		</div>
		<?php } ?>
		<?php if(canRoomAction($user) || canEditUser($user, 8) && insideChat($cur_page) && !isBot($user['user_bot'])){ ?>
		<div class="tpad15">
			<p class="text_med bold"><?php echo $lang['room_action']; ?></p>
			<?php if(boomRole(5) || boomAllow(9)){ ?>
			<div class="setting_element">
				<p class="label"><?php echo $lang['room_rank']; ?></p>
				<select id="room_ranking" onchange="changeRoomRank(this, <?php echo $user['user_id']; ?>);">
					<?php echo changeRoomRank($user['room_ranking']); ?>
				</select>
			</div>
			<?php } ?>
			<div class="setting_element">
				<p class="label"><?php echo $lang['do_action']; ?></p>
				<select id="set_room_action" onchange="takeAction(this, <?php echo $user['user_id']; ?>);">
					<?php echo listRoomAction($user); ?>
				</select>
			</div>
			<?php } ?>
		</div>
	</div>
	<?php } ?>
</div>