<?php
$nlang['like'] = 'A réagit à une de vos publications';
$nlang['reply'] = 'A commenté sur une de vos publications';
$nlang['add_post'] = 'A publié quelque chose sur le mur';
$nlang['accept_friend'] = 'A acceptée votre demande amis';
$nlang['word_mute'] = 'Vous avez été mis en silence %delay% pour language abusif';
$nlang['flood_mute'] = 'Votre compte a été mis en silence %delay% pour flood';
$nlang['spam_mute'] = 'Vous avez été mis en silence %delay% pour spam';
$nlang['rank_change'] = 'Votre rank a changé vous êtes maintenant %rank%';
$nlang['mute'] = 'Vous avez été mis en silence pour %delay%';
$nlang['unmute'] = 'Votre silence a été enlever';
$nlang['name_change'] = 'A changer votre pseudo par %data%';
$nlang['prolike'] = 'Has liked your profile';
$nlang['main_mute'] = 'Vous avez été mis en silence du chat principal pour %delay%';
$nlang['private_mute'] = 'Votre chat privé mis en silence %delay%';
$nlang['main_unmute'] = 'Votre silence a été enlever sur le chat principal';
$nlang['private_unmute'] = 'Your private has been unmuted';
$nlang['gold_share'] = 'a partagé %data% gold avec vous';
$nlang['gift'] = 'Vous a envoyé un cadeau';
$nlang['vipgift'] = 'Vous a envoyé un abonnement vip';
$nlang['vipsys'] = 'Votre abonnement vip a été ajouter a votre compte';
$nlang['custom'] = '%custom%';
?>