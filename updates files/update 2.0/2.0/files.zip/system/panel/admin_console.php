<?php
require('../config_session.php');
require('../language/' . $data['user_language'] . '/console.php');

if(!boomAllow(10)){
	echo 0;
	die();
}
?>
<div id="console_logs_box" class="pad15">
	<div class="bpad25 console_logs_search">
		<input onkeyup="searchSystemConsole();" id="search_system_console" placeholder="&#xf002;" class="full_input" type="text"/>
	</div>
	<div id="console_results" class="box_height400">
	</div>
	<div id="console_spinner" class="vpad10 centered_element">
		<i class="text_jumbo fa fa-spinner fa-spin"></i>
	</div>
</div>