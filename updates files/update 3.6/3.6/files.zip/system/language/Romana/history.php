<?php
$hlang['flood_mute'] = 'Flood linisteste';
$hlang['word_mute'] = 'Word linisteste';
$hlang['word_kick'] = 'Word da afara';
$hlang['spam_mute'] = 'Spam linisteste';
$hlang['spam_ban'] = 'Spam baneaza';
$hlang['mute'] = 'Linisteste';
$hlang['ban'] = 'Baneaza';
$hlang['kick'] = 'Da afara';
?>