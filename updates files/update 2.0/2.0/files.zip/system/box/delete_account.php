<?php
require_once('../config_session.php');

if(!isset($_POST['account'])){
	die();
}
$account = escape($_POST['account']);
?>
<div class="pad_box">
	<div class="vpad15">
		<p class="centered_element" ><?php echo $lang['want_delete']; ?></p>
	</div>
	<div class="centered_element">
		<button onclick="confirmDelete(<?php echo $account; ?>);" class="reg_button theme_btn"><i class="fa fa-check"></i> <?php echo $lang['yes']; ?></button>
		<button class="reg_button cancel_modal default_btn"><?php echo $lang['cancel']; ?></button>
	</div>
</div>