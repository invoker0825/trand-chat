<?php
$boom_version = 'php70';
$pversion = PHP_MAJOR_VERSION . PHP_MINOR_VERSION;
if($pversion >= 71){
	$boom_version = 'php71';
}
if($pversion >= 72){
	$boom_version = 'php72';
}
?>