<?php
$hlang['flood_mute'] = 'Wiederholung-Stumm';
$hlang['word_mute'] = 'Schimpfwörter - Stumm';
$hlang['word_kick'] = 'schimpfwörter - Kick';
$hlang['spam_mute'] = 'Spam-Stumm';
$hlang['spam_ban'] = 'Spam-gesperrt';
$hlang['mute'] = 'Stummschaltung';
$hlang['ban'] = 'gesperrt';
$hlang['kick'] = 'gekickt';
?>