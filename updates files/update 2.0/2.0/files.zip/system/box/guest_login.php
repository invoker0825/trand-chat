<?php
require('../config.php');
if(!allowGuest()){
	die();
}
?>
<div id="guest_form_box" class="pad_box">
	<div class="boom_form">
		<p class="label"><?php echo $lang['username']; ?></p>
		<input id="guest_username" class="user_username full_input" type="text" maxlength="<?php echo $data['max_username']; ?>" name="username" autocomplete="off">
	</div>
	<?php if(boomRecaptcha()){ ?>
	<div class="recapcha_div tmargin5">
		<div id="boom_recaptcha" class="guest_recaptcha">
		</div>
	</div>
	<?php } ?>
	<div class="login_control">
		<button onclick="sendGuestLogin();" type="button" class="theme_btn full_button large_button"><i class="fa fa-sign-in"></i> <?php echo $lang['login']; ?></button>
	</div>
</div>