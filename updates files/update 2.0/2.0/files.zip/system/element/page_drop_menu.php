<div class="page_drop_control page_menu_item">
	<div class="page_menu_icon">
		<i class="fa fa-<?php echo $boom['icon']; ?>"></i>
	</div>
	<div class="page_menu_text">
		<?php echo $boom['txt']; ?>
	</div>
	<div class="page_drop_icon">
		<i class="pclose fa fa-chevron-down"></i>
		<i class="popen fa fa-chevron-up"></i>
	</div>
</div>
<div class="page_drop">
	<?php echo $boom['drop']; ?>
</div>