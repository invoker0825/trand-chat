<?php
/**
* Codychat
*
* @package Codychat
* @author www.boomcoding.com
* @copyright 2018
* @terms any use of this script without a legal license is prohibited
* all the content of Codychat is the propriety of BoomCoding and Cannot be 
* used for another project.
*/
require_once('config_session.php');

function userPostChatFile($content, $file_name, $type, $file_name2 = ''){
	global $mysqli, $data;
	$lact = calMinutes(3);
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, file) VALUES ('" . time() . "', '{$data['user_id']}', '$content', '{$data['user_roomid']}', 'public', '1')");
	$rel = $mysqli->insert_id;
	$mysqli->query("UPDATE boom_users SET caction = caction + 1 WHERE user_roomid = '{$data['user_roomid']}' and last_action > '$lact'");
	if($file_name2 != ''){
		$mysqli->query("INSERT INTO `boom_upload` (file_name, date_sent, file_user, file_zone, file_type, relative_post) VALUES
		('$file_name', '" . time() . "', '{$data['user_id']}', 'chat', '$type', '$rel'),
		('$file_name2', '" . time() . "', '{$data['user_id']}', 'chat', '$type', '$rel')
		");
	}
	else {
		$mysqli->query("INSERT INTO `boom_upload` (file_name, date_sent, file_user, file_zone, file_type, relative_post) VALUES ('$file_name', '" . time() . "', '{$data['user_id']}', 'chat', '$type', '$rel')");
	}
	return true;
}

if(!boomAllow($data['allow_image']) || muted() || roomMuted()){ 
	die();
}
if (isset($_FILES["file"])){
	ini_set('memory_limit','128M');
	$info = pathinfo($_FILES["file"]["name"]);
	$extension = $info['extension'];
	$origin = escape(filterOrigin($info['filename']) . '.' . $extension);
	if ( fileError() ){
		echo 1;
		die();
	}
	if (isImage($extension)){
		$imginfo = getimagesize($_FILES["file"]["tmp_name"]);
		if ($imginfo !== false) {
			
			$width = $imginfo[0];
			$height = $imginfo[1];
			$type = $imginfo['mime'];
			
			$fname = encodeFileTumb($extension);
			$file_name = $fname['full'];
			$file_tumb = $fname['tumb'];
			
			move_uploaded_file(preg_replace('/\s+/', '', $_FILES["file"]["tmp_name"]), "../upload/chat/" . $file_name);
			
			$source = '../upload/chat/' . $file_name;
			$tumb = '../upload/chat/' . $file_tumb;
			$img_path = $data['domain'] . "/upload/chat/" . $file_name;
			$tumb_path = $data['domain'] . "/upload/chat/" . $file_tumb;
			
			$create = imageTumb($source, $tumb, $type, 180);
			if(file_exists($source) && file_exists($tumb)){
				$check_tumb = getimagesize($tumb);
				if ($check_tumb !== false) {
					$myimage = tumbLinking($img_path, $tumb_path);
					userPostChatFile($myimage, $file_name, 'image', $file_tumb);
				}
				else {
					$myimage = linking($img_path);
					userPostChatFile($myimage, $file_name, 'image');
				}
			}
			else {
				$myimage = linking($img_path);
				userPostChatFile($myimage, $file_name, 'image');
			}
			echo 5;
			die();
			
			
		}
		else {
			echo 1;
			die();
		}
	}
	else if (isFile($extension)){
		$file_name = encodeFile($extension);
		move_uploaded_file(preg_replace('/\s+/', '', $_FILES["file"]["tmp_name"]), "../upload/chat/" . $file_name);
		$myfile = $data['domain'] . "/upload/chat/" . $file_name;
		$myfile =  fileProcess($myfile, $origin);
		userPostChatFile($myfile, $file_name, 'file');
		echo 5;
		die();
	}
	else if (isMusic($extension)){
		$file_name = encodeFile($extension);
		move_uploaded_file(preg_replace('/\s+/', '', $_FILES["file"]["tmp_name"]), "../upload/chat/" . $file_name);
		$myfile = $data['domain'] . "/upload/chat/" . $file_name;
		$myfile =  musicProcess($myfile, $origin);
		userPostChatFile($myfile, $file_name, 'music');
		echo 5;
		die();
	}
	else {
		echo 1;
	}
}
else {
	echo 1;
}
?> 