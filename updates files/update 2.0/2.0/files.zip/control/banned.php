<div class="out_page_container back_dark">
	<div class="out_page_content">
		<div class="out_page_box">
			<div class="pad_box">
				<i class="error fa fa-ban text_ultra"></i>
				<p class="centered_element text_med vmargin10"><?php echo $lang['site_banned']; ?></p>
			</div>
		</div>
	</div>
</div>
