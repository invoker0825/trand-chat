<?php
$hlang['flood_mute'] = 'Silenciado por atiborramiento';
$hlang['word_mute'] = 'Silenciado por ofensivo';
$hlang['word_kick'] = 'Expulsado por ofensivo';
$hlang['spam_mute'] = 'Silenciado por spam';
$hlang['spam_ban'] = 'Baneado por spam';
$hlang['mute'] = 'Silenciado';
$hlang['ban'] = 'Baneado';
$hlang['kick'] = 'Expulsado';
?>