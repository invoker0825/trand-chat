<div class="active_embed">
	<img alt="<?php echo $boom['user_name']; ?>" title="<?php echo $boom['user_name']; ?>" class="active_embed_user" src="<?php echo myAvatar($boom['user_tumb']); ?>"/>
</div>