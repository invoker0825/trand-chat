<div class="page_full vheight">
	<?php echo pageTitle($lang['terms'], 'gavel'); ?>
	<div class="page_element">
		<div class="pad15">
		<?php echo loadPageData('terms_of_use'); ?>
		</div>
	</div>
</div>