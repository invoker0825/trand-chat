<div class="page_full">
	<div class="page_element">
		<?php echo loadPageData('terms_of_use'); ?>
	</div>
	<div class="pad15">
		<?php boomFooterMenu(); ?>
	</div>
</div>