<?php
$nlang['like'] = 'A reacționat la una dintre postările tale';
$nlang['reply'] = 'A comentat una dintre postările tale';
$nlang['add_post'] = 'Postat ceva pe perete';
$nlang['accept_friend'] = 'A acceptat cererea de prietenie';
$nlang['word_mute'] = 'Ai fost Linisteste %delay% folosind cuvinte neadecvate';
$nlang['flood_mute'] = 'Ai fost linistit %delay% pentru flood';
$nlang['spam_mute'] = 'Ai fost linistit %delay% pentru spam';
$nlang['rank_change'] = 'Rangul dvs. a fost schimbare acum sunteți %rank%';
$nlang['mute'] = 'Ai fost linistit %delay%';
$nlang['unmute'] = 'Poti Reintra Ai fost Activat';
$nlang['name_change'] = 'Ați schimbat numele de utilizator %data%';
?>