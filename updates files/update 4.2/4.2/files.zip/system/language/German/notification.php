<?php
$nlang['like'] = 'Hat auf deinen Beiträge reagiert';
$nlang['reply'] = 'Hat deinen Beitrag kommentiert';
$nlang['add_post'] = 'Hat etwas an die Wand gehängt';
$nlang['accept_friend'] = 'Hat deine Freundschaftsanfrage angenommen';
$nlang['word_mute'] = 'Du wurdest wegen Beschimpfungen für %delay% Stumm gestellt';
$nlang['flood_mute'] = 'Du wurdest wegen Wiederholungen für %delay% Stumm gestellt';
$nlang['spam_mute'] = 'Du wurdest stumm geschaltet %delay% wegen Spam';
$nlang['rank_change'] = 'Dein Rang hat sich geändert, du bist jetzt ein anderer %rank%';
$nlang['mute'] = 'Du wurdest stummgeschaltet für %delay%';
$nlang['unmute'] = 'Du wurdest freigestellt';
$nlang['name_change'] = 'Hat deinen Benutzernamen geändert als %data%';
$nlang['prolike'] = 'Ihrem Konto wurde eine VIP-Mitgliedschaft hinzugefügt';
$nlang['main_mute'] = 'Du wurdest im Hauptchat stummgeschaltet %delay%';
$nlang['private_mute'] = 'Du wurdest privat stummgeschaltet %delay%';
$nlang['main_unmute'] = 'Die Stummschaltung im Hauptchat wurde aufgehoben';
$nlang['private_unmute'] = 'Die Stummschaltung Ihrer privaten Verbindung wurde aufgehoben';
$nlang['gold_share'] = 'Hat geteilt %data% Gold mit dir';
$nlang['gift'] = 'Hat dir ein Geschenk geschickt';
$nlang['vipgift'] = 'Hat Ihnen eine VIP-Mitgliedschaft geschickt';
$nlang['vipsys'] = 'Ihrem Konto wurde eine VIP-Mitgliedschaft hinzugefügt';
$nlang['custom'] = '%custom%';
?>