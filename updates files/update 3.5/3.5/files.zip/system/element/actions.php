<div class="avheader">
	<div class="avtop btable top_background topcard avbackground">
		<div class="bcell_mid">
			<div class="avtopmenu btable">
				<div class="bcell_mid">
				</div>
			</div>
			<div class="btable avavpart">
				<div class="bcell_mid avtop_content">
					<img class="avavatar"  src=""/>
				</div>
			</div>
			<div class="btable avdetails">
				<p class="avusername cover_text bellips"></p>
				<p class="avagegender cover_text bellips"><span class="avage"></span> <span class="avgender"></span></p>
				<img src="" class="avflag"/>
			</div>
		</div>
	</div>
</div>
<div class="avself background_box bottomcard">
	<div data="" value="" data-av="" class="avset avitem get_info">
		<i class="fa fa-user-circle-o default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av="" class="avset avitem" onclick="editProfile();">
		<i class="fa fa-edit theme_color"></i> <?php echo $lang['edit']; ?>
	</div>
</div>
<div class="avbot background_box bottomcard">
	<div data="" value="" data-av="" class="avset avitem get_info">
		<i class="fa fa-user-circle-o default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avitem gprivate">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private']; ?>
	</div>
</div>
<div class="avstaff background_box bottomcard">
	<div data="" value="" data-av="" class="avset avitem get_info">
		<i class="fa fa-user-circle-o default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avitem gprivate">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private_chat']; ?>
	</div>
	<div data="" value="" data-av="" class="avset avitem get_actions avactions">
		<i class="fa fa-flash error"></i> <?php echo $lang['do_action']; ?>
	</div>
</div>
<div class="avroomstaff background_box bottomcard">
	<div data="" value="" data-av="" class="avset avitem get_info">
		<i class="fa fa-user-circle-o default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avitem gprivate">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private_chat']; ?>
	</div>
	<div data="" value="" data-av="" class="avset avitem get_room_actions avactions">
		<i class="fa fa-flash error"></i> <?php echo $lang['do_action']; ?>
	</div>
</div>
<div class="avother background_box bottomcard">
	<div data="" value="" data-av="" class="avset avitem get_info">
		<i class="fa fa-user-circle-o default_color"></i> <?php echo $lang['info']; ?>
	</div>
	<div data="" value="" data-av=""  class="avset avitem gprivate">
		<i class="fa fa-comments theme_color"></i> <?php echo $lang['private']; ?>
	</div>
</div>