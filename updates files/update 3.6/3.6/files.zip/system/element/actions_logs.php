<div data="" onclick="deleteLog(this);" class="fmenu_item fmenut log_menu_item log_delete">
	<?php echo $lang['delete']; ?>
</div>
<div data="" onclick="reportChatLog(this);" class="fmenu_item fmenut log_menu_item log_report">
	<?php echo $lang['report']; ?>
</div>