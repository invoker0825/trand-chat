<?php
require('config_session.php');

if(isset($_POST['update_status'])){
	$status = escape($_POST['update_status']);
	if($status == 6 && !boomAllow(9)){
		echo 2;
		die();
	}
	$mysqli->query("UPDATE boom_users SET user_status = '$status' WHERE user_id = '{$data['user_id']}'");
	echo 1;
	die();
}
if(isset($_POST['actual_pass'], $_POST['new_pass'], $_POST['repeat_pass'], $_POST['change_password'])){
	require_once("config_session.php");
	$pass = escape($_POST['actual_pass']);
	$new_pass = escape($_POST['new_pass']);
	$repeat_pass = escape($_POST['repeat_pass']);
	$actual_encrypt = encrypt($pass);
	if($actual_encrypt != $data['user_password'] && $pass != $data['temp_pass']){
		echo 5;
		die();
	}
	if($pass == '' || $new_pass == '' || $repeat_pass == ''){
		echo 2;
		die();
	}
	if($new_pass != $repeat_pass){
		echo 3;
		die();
	}
	if(strlen($new_pass) > 30 || strlen($new_pass) < 4){
		echo 4;
		die();
	}
	if($pass == '0' || $new_pass == '0' || $repeat_pass == '0'){
		echo 5;
		die();
	}
	$new_encrypted_pass = encrypt($new_pass);
	$mysqli->query("UPDATE boom_users SET user_password = '$new_encrypted_pass', temp_pass = '0' WHERE user_id = '{$data['user_id']}'");
	setBoomCookie($data['user_id'], $new_encrypted_pass);
	echo 1;
	die();
}
if(isset($_POST['edit_username'], $_POST['new_name'])){
	$new_name = escape($_POST['new_name']);
	if(!boomAllow($data['allow_name'])){
		die();
	}
	if($new_name == $data['user_name']){
		echo 1;
		die();
	}
	if(!validate_name($new_name)){
		echo 2;
		die();
	}
	if(!boomSameName($new_name, $data['user_name'])){
		if(!boomUsername($new_name)){
			echo 3;
			die();
		}
	}
	$mysqli->query("UPDATE boom_users SET user_name = '$new_name' WHERE user_id = '{$data['user_id']}'");
	selfConsole('change_name', $data['user_name']);
	echo 1;
	die();
}
if(isset($_POST['reload_avatar'])){
	$profile_avatar = '<img class="fancybox avatar_profile" ' . profileAvatar($data['user_tumb']) . '/>';
	$avatar_link = myavatar($data['user_tumb']);
	echo json_encode( array( "profile_avatar" => $profile_avatar, "avatar_link"=> $avatar_link,), JSON_UNESCAPED_UNICODE);
	die();
}
if(isset($_POST['delete_avatar'])){
	$reset = resetAvatar($data);
	$profile_avatar = '<img class="fancybox avatar_profile" ' . profileAvatar($reset, $reset) . '/>';
	$avatar_link = myavatar($reset);
	echo json_encode( array( "profile_avatar" => $profile_avatar, "avatar_link"=> $avatar_link,), JSON_UNESCAPED_UNICODE);
	die();
}
if(isset($_POST['save_color'], $_POST['save_bold'])){
	$c = escape($_POST['save_color']);
	$b = escape($_POST['save_bold']);
	if(!validTextColor($c)){
		echo 0;
		die();
	}
	if($b == 'bolded' || $b == ''){
		$mysqli->query("UPDATE boom_users SET bccolor = '$c', bcbold = '$b' WHERE user_id = '{$data['user_id']}'");
		echo 1;
		die();
	}
	else {
		echo 0;
		die();
	}
}
if(isset($_POST['save_mood'])){
	$mood = escape($_POST['save_mood']);
	if(!boomAllow($data['allow_mood'])){
		echo 0;
		die();
	}
	if(isBadText($mood)){
		echo 2;
		die();
	}
	if(isTooLong($mood, 40)){
		echo 0;
		die();
	}
	if($mood == $data['user_mood']){
		echo getMood($data);
		die();
	}
	$mysqli->query("UPDATE boom_users SET user_mood = '$mood' WHERE user_id = '{$data['user_id']}'");
	$u = userDetails($data['user_id']);
	echo getMood($u);
	die();
	
}	
if(isset($_POST['save_profile'], $_POST['age'], $_POST['gender'], $_POST['country'], $_POST['about'])){
	$age = escape($_POST['age']);
	$gender = escape($_POST['gender']);
	$country = escape($_POST['country']);
	$about = escape($_POST['about']);
	if(isTooLong($about, 900) || !validGender($gender) || !validCountry($country) || !validAge($age)) {
		echo 0;
		die();
	}
	$mysqli->query("UPDATE boom_users SET user_age = '$age', user_sex = '$gender', country = '$country', user_about = '$about' WHERE user_id = '{$data['user_id']}'");
	echo 1;
	die();
}
if(isset($_POST['email'], $_POST['password'])){
	$email = escape($_POST['email']);
	$password = escape($_POST['password']);
	if(!boomAllow(1)){
		die();
	}
	if(!userPassword($password)){
		echo 3;
		die();
	}
	if(!validEmail($email)){
		echo 2;
		die();
	}
	$mysqli->query("UPDATE boom_users SET user_email = '$email' WHERE user_id = '{$data['user_id']}'");
	echo 1;
	die();
}
if(isset($_POST['delete_account_password'], $_POST['delete_my_account'])){
	$pass = escape($_POST['delete_account_password']);
	$delay = calDayUp(7);
	if(boomAllow(11) || isBot($data['user_bot'])){
		die();
	}
	if(!userPassword($pass)){
		echo 2;
		die();
	}
	$mysqli->query("UPDATE boom_users SET user_delete = '$delay' WHERE user_id = '{$data['user_id']}' AND user_delete = 0");
	echo 1;
	die();
}
if(isset($_POST['cancel_delete_account'])){
	$mysqli->query("UPDATE boom_users SET user_delete = '0' WHERE user_id = '{$data['user_id']}'");
	echo 1;
	die();
}
if(isset($_POST['my_username_color'])){
	$color = escape($_POST['my_username_color']);
	if(!validNameColor($color)){
		echo 0;
		die();
	}
	$mysqli->query("UPDATE boom_users SET user_color = '$color' WHERE user_id = '{$data['user_id']}'");
	echo 1;
	die();
}
if(isset($_POST['set_private_mode'])){
	$pmode = escape($_POST['set_private_mode']);
	if(isGuest($data['user_rank'])){
		if($pmode != 0 && $pmode != 1){
			echo 0;
			die();
		}
	}
	if($pmode == 0 || $pmode == 1 || $pmode == 2 || $pmode == 3){
		$mysqli->query("UPDATE boom_users SET user_private = '$pmode' WHERE user_id = '{$data['user_id']}'");
		echo 1;
		die();
	}
	else {
		echo 0;
		die();
	}
}
if(isset($_POST['change_sound'])){
	$sound = escape($_POST['change_sound']);
	if($sound == 0 || $sound == 1 || $sound == 2 ){
		$mysqli->query("UPDATE boom_users SET user_sound = '$sound' WHERE user_id = '{$data['user_id']}'");
		echo 1;
		die();
	}
	else {
		echo 0;
		die();
	}
}
?>