<div class="page_element">
	<div class="btable">
		<div class="bcell_mid page_ticon back_theme">
			<i class="fa fa-<?php echo $boom['icon']; ?>"></i>
		</div>
		<div class="bcell_mid page_ttext">
			<?php echo $boom['title']; ?>
		</div>
	</div>
</div>