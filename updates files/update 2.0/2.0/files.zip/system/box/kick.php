<?php
require('../config_session.php');
if(!isset($_POST['kick'])){
	die();
}
if(!boomAllow(8)){
	die();
}
$target = escape($_POST['kick']);
$user = userDetails($target);
?>
<div class="pad_box">
	<div class="setting_element">
		<p class="label"><?php echo $lang['duration']; ?></p>
		<select id="kick_delay">
			<?php echo boomTemplate('element/kick_options', 0); ?>
		</select>
	</div>
	<div class="setting_element">
		<p class="label"><?php echo $lang['reason']; ?></p>
		<input id="kick_reason" maxlength="300" class="full_input" type="text"/></input>
	</div>
	<div class="tpad10">
		<button onclick="kickUser(<?php echo $user['user_id']; ?>);" class="reg_button delete_btn"><?php echo $lang['kick']; ?></button>
		<button class="close_over reg_button default_btn"><?php echo $lang['cancel']; ?></button>
	</div>
</div>