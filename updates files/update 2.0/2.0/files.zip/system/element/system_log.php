<li  class="other_logs <?php echo $boom['type']; ?>">
	<div class="chat_avatar">
		<img src="<?php echo myavatar($boom['avatar']); ?>"/>
	</div>
	<div class="my_text">
		<div class="btable">
			<div class="cname">
				<span class="username"><?php echo $boom['name']; ?></span>
			</div>
			<?php if($boom['delete'] == 1){ ?>
			<div onclick="hideThisPost(this)"; class="spclear">
				<i class="fa fa-times"></i>
			</div>
			<?php } ?>
		</div>
		<div class="chat_message">
			<?php echo $boom['content']; ?>
		</div>
	</div>
</li>