<div class="container_up_file">
	<div class="btable file_share file_color">
		<div class="bcell_mid_center file_type">
			<i class="fa fa-file"></i> 
		</div>
		<div class="bcell_mid ellips text_small file_title">
			<?php echo $boom['title']; ?>
		</div>
		<div class="bcell_mid_center file_download">
			<a class="upc_file" href="<?php echo $boom['file']; ?>" download="<?php echo $boom['title']; ?>" >
			<i class="fa fa-download"></i>
			</a>
		</div>
	</div>
</div>