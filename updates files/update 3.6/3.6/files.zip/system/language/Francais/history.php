<?php
$hlang['flood_mute'] = 'Silence flood';
$hlang['word_mute'] = 'Silence language';
$hlang['word_kick'] = 'Kick language';
$hlang['spam_mute'] = 'Silence spam';
$hlang['spam_ban'] = 'Ban spam';
$hlang['mute'] = 'Silence';
$hlang['ban'] = 'Ban';
$hlang['kick'] = 'Kick';
?>