<?php
$nlang['like'] = 'Оценил Ваш пост';
$nlang['reply'] = 'Прокомментировал Ваш пост';
$nlang['add_post'] = 'Разместил что-то на стене';
$nlang['accept_friend'] = 'Принял ваш запрос на добавление в друзья';
$nlang['word_mute'] = 'Вы получили кляп %delay% за мат';
$nlang['flood_mute'] = 'Вы получили кляп %delay% за флуд';
$nlang['spam_mute'] = 'Вы получили кляп %delay% за спам';
$nlang['rank_change'] = 'Ваш ранг был изменен на %rank%';
$nlang['mute'] = 'Вы получили кляп %delay%';
$nlang['unmute'] = 'С Вас сняли кляп';
$nlang['name_change'] = 'Изменил Ваш ник %data%';
?>