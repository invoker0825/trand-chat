<div data="<?php echo $boom['load']; ?>" class="get_dat page_menu_item">
	<div class="page_menu_icon">
		<i class="fa fa-<?php echo $boom['icon']; ?> menup"></i>
	</div>
	<div class="page_menu_text">
		<?php echo $boom['txt']; ?>
	</div>
</div>