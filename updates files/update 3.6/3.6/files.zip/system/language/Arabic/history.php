<?php
$hlang['flood_mute'] = 'كتم الفيضان';
$hlang['word_mute'] = 'كلمة الكتم';
$hlang['word_kick'] = 'كلمة الطرد';
$hlang['spam_mute'] = 'كتم البريد المزعج';
$hlang['spam_ban'] = 'حظر البريد المزعج';
$hlang['mute'] = 'كتم';
$hlang['ban'] = 'حظر';
$hlang['kick'] = 'طرد';
?>