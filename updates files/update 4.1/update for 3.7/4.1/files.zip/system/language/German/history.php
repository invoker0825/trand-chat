<?php
$hlang['flood_mute'] = 'Wiederholung-Stumm';
$hlang['word_mute'] = 'Schimpfwörter - Stumm';
$hlang['word_kick'] = 'schimpfwörter - Trete';
$hlang['spam_mute'] = 'Spam-Stumm';
$hlang['spam_ghost'] = 'Spam-Geist';
$hlang['spam_ban'] = 'Spam-gesperrt';
$hlang['mute'] = 'Stummschaltung';
$hlang['ban'] = 'gesperrt';
$hlang['kick'] = 'gekickt';
$hlang['flood_kick'] = 'Flutstoß';
$hlang['vpn_kick'] = 'VPN-Trete';
$hlang['main_mute'] = 'Hauptstummschaltung';
$hlang['private_mute'] = 'Privatgelände Stummschaltung';
$hlang['ghost'] = 'Geist';
?>