<?php
require('../config_session.php');
?>
<div class="modal_wrap_top modal_top">
	<div class="btable profile_top">
		<div id="proav" class="profile_avatar" data="<?php echo $data['user_tumb']; ?>" >
			<div class="avatar_spin">
				<img class="fancybox avatar_profile" <?php echo profileAvatar($data['user_tumb']); ?>/>
			</div>
			<?php if(boomAllow($data['allow_avatar'])){ ?>
			<div class="avatar_control olay">
				<div class="button full_button avatar_button" onclick="deleteAvatar();" id="delete_avatar"><i class="fa fa-times"></i></div>
				<div id="avatarupload" class="avatar_button">
					<form id="avatar_form" action="system/avatar.php" method="post" enctype="multipart/form-data">
						<div class="button choose_avatar full_button">
							<span><i class="fa fa-camera"></i></span>
							<input class="upload avatar_select" type="file" name="file" id="avatar_image">
						</div>
						<input type="hidden" value="<?php echo setToken(); ?>" name="token"> 
					</form>
				</div>
			</div>
			<?php } ?>
		</div>
		<div class="profile_tinfo">
			<div class="pdetails">
				<?php if(boomAllow($data['allow_name'])){ ?> 
				<div class="pdetails_icon text_med bold bclick" onclick="changeUsername();">
					<i  class="fa fa-pencil"></i>
				</div>
				<?php } ?>
				<div id="pro_name" class="pdetails_text pro_name">
					<?php echo $data['user_name']; ?>
				</div>
			</div>
			<?php if(boomAllow($data['allow_mood'])){ ?>
			<div class="pdetails sub_dark">
				<div class="pdetails_icon text_med bclick" onclick="changeMood();">
					<i  class="fa fa-pencil"></i>
				</div>
				<div id="pro_mood" class="pdetails_text pro_mood bellips">
					<?php echo getMood($data); ?>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
	<div class="cancel_modal profile_close">
		<i class="fa fa-times"></i>
	</div>
</div>
<?php if(userDelete($data)){ ?>
<div id="delete_warn" class="pad15 warn_btn">
	<p class="text_xsmall">
	<span><?php echo str_replace('%date%', longDate($data['user_delete']), $lang['close_warning']); ?></span> 
	<span onclick="cancelDelete();" class="link_like"><?php echo $lang['cancel_request']; ?></span>
	</p>
</div>
<?php } ?>
<div class="modal_menu">
	<ul>
		<?php if(guestCanRegister()){ ?>
		<li class="modal_menu_item reg_guest ok_btn" data="guest_register"><i class="fa fa-edit"></i> <?php echo $lang['register']; ?></li>
		<?php } ?>
		<li id="pro_info_tab" class="modal_menu_item modal_selected"  data="personal_info"><?php echo $lang['about_me']; ?></li>
		<?php if(boomAllow(1)){ ?>
		<li class="modal_menu_item" data="personal_friends"><?php echo $lang['friends']; ?></li>
		<?php } ?>
		<li class="modal_menu_item" data="personal_ignores"><?php echo $lang['ignore_list']; ?></li>
		<li class="modal_menu_item" data="personal_options"><?php echo $lang['options']; ?></li>
		<li class="modal_menu_item" data="personal_more"><?php echo $lang['more']; ?></li>
	</ul>
</div>
<div class="modal_zone pad25 tpad15" id="personal_info">
	<div class="boom_form bpad10">
		<div class="form_split">
			<div class="form_left">
				<div class="setting_element ">
					<p class="label"><?php echo $lang['age']; ?></p>
					<select id="set_profile_age">
						<?php echo listAge($data['user_age'], 2); ?>
					</select>
				</div>
			</div>
			<div class="form_right">
				<div class="setting_element ">
					<p class="label"><?php echo $lang['gender']; ?></p>
					<select id="set_profile_gender">
						<?php echo listGender($data['user_sex']); ?>
					</select>
				</div>
			</div>
		</div>
		<div class="form_split">
			<div class="setting_element ">
				<p class="label"><?php echo $lang['country']; ?></p>
				<select id="set_profile_country">
					<?php echo listCountry($data['country']); ?>
				</select>
			</div>
		</div>
		<div class="form_split">
			<div class="setting_element">
				<p class="label"><?php echo $lang['about_me']; ?></p>
				<textarea id="set_user_about" class="large_textarea about_area full_textarea" spellcheck="false" maxlength="800" ><?php echo $data['user_about']; ?></textarea>
			</div>
		</div>
	</div>
	<button type="button" onclick="saveProfile();" id="save_profile" class="mod_button theme_btn"><i class="fa fa-floppy-o"></i> <?php echo $lang['save']; ?></button>
</div>
<?php if(guestCanRegister()){ ?>
<div class="modal_zone  pad_box hide_zone" id="guest_register">
	<div class="boom_form">
		<div class="setting_element">
			<p class="label"><?php echo $lang['username']; ?></p>
			<input type="text" <?php if(validate_name($data['user_name'])){ echo ' value="' . $data['user_name'] . '" '; } ?> id="new_guest_name" placeholder="<?php echo $lang['username']; ?>" class="full_input"/>
		</div>
		<div class="setting_element">
			<p class="label"><?php echo $lang['password']; ?></p>
			<input type="text" id="new_guest_password" placeholder="<?php echo $lang['password']; ?>" class="full_input"/>
		</div>
		<div class="setting_element">
			<p class="label"><?php echo $lang['email']; ?></p>
			<input type="text" id="new_guest_email" placeholder="<?php echo $lang['email']; ?>" class="full_input"/>
		</div>
	</div>
	<button onclick="registerGuest();" class="reg_button theme_btn"><i class="fa fa-edit"></i> <?php echo $lang['register']; ?></button>
</div>
<?php } ?>
<div class="modal_zone hide_zone" id="personal_friends">
	<div class="ulist_container">
		<?php echo myFriend(); ?>
	</div>
</div>
<div class="modal_zone hide_zone" id="personal_ignores">
	<div class="ulist_container">
		<?php echo myIgnore(); ?>
	</div>
</div>
<div class="modal_zone  pad25 hide_zone" id="personal_options">
	<div class="boom_form">
		<div class="form_split">
			<div class="form_left_full">
				<div class="setting_element ">
					<p class="label"><?php echo $lang['language']; ?></p>
					<select onchange="setUserLang();" id="set_profile_language">
						<?php echo listLanguage($data['user_language'], 1); ?>
					</select>
				</div>
			</div>
			<div class="form_right_full">
				<div class="setting_element ">
					<p class="label"><?php echo $lang['user_timezone']; ?></p>
					<select onchange="setUserTime();" id="set_user_timezone">
						<?php echo getTimezone($data['user_timezone']); ?>
					</select>
				</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="form_split">
			<div class="form_left">
				<div class="setting_element ">
					<p class="label"><?php echo $lang['sounds']; ?></p>
					<select id="set_sound" onchange="setUserSound(this);">
						<option <?php echo selCurrent($data['user_sound'], 0); ?> value="0"><?php echo $lang['no_sound']; ?></option>
						<option <?php echo selCurrent($data['user_sound'], 1); ?> value="1"><?php echo $lang['private_sound']; ?></option>
						<option <?php echo selCurrent($data['user_sound'], 2); ?> value="2"><?php echo $lang['all_sound']; ?></option>
					</select>
				</div>
			</div>
			<div class="form_right">
				<div class="setting_element ">
					<p class="label"><?php echo $lang['private_mode']; ?></p>
					<select onchange="setPrivateMode(this);" id="set_private_mode">
						<option <?php echo selCurrent($data['user_private'], 1); ?> value="1"><?php echo $lang['on']; ?></option>
						<?php if(boomAllow(1)){ ?>
						<option <?php echo selCurrent($data['user_private'], 3); ?> value="3"><?php echo $lang['user']; ?></option>
						<option <?php echo selCurrent($data['user_private'], 2); ?> value="2"><?php echo $lang['friend_only']; ?></option>
						<?php } ?>
						<option <?php echo selCurrent($data['user_private'], 0); ?> value="0"><?php echo $lang['off']; ?></option>
					</select>
				</div>
			</div>
			<div class="clear"></div>
		</div>
		<?php if(boomAllow($data['allow_theme'])){ ?>
		<div class="setting_element ">
			<p class="label"><?php echo $lang['user_theme']; ?></p>
			<select id="set_user_theme" onchange="setUserTheme(this);">
				<?php echo listTheme($data['user_theme'], 2); ?>
			</select>
		</div>
		<?php } ?>
	</div>
	<?php if(canNameColor()){ ?>
	<div class="user_edit_color">
		<p class="label"><?php echo $lang['user_color']; ?></p>
		<div class="my_name_color" data="<?php echo $data['user_color']; ?>">
			<?php if(canNameGrad()){ ?>
			<div class="reg_menu_container tmargin10">		
				<div class="reg_menu">
					<ul>
						<li class="reg_menu_item reg_selected" data="color_tab" data-z="reg_color"><?php echo $lang['color']; ?></li>
						<li class="reg_menu_item" data="color_tab" data-z="grad_color"><?php echo $lang['gradient']; ?></li>
					</ul>
				</div>
			</div>
			<?php } ?>
			<div id="color_tab">
				<div id="reg_color" class="reg_zone vpad5">
					<?php echo colorChoice($data['user_color'], 3); ?>
					<div class="clear"></div>
				</div>
				<?php if(canNameGrad()){ ?>
				<div id="grad_color" class="reg_zone vpad5 hide_zone">
					<?php echo gradChoice($data['user_color'], 3); ?>
					<div class="clear"></div>
				</div>
				<?php } ?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<?php } ?>
	<div class="clear"></div>
</div>
<div class="modal_zone hide_zone" id="personal_more">
	<div class="pad25">
		<div>
			<?php if($data['verified'] == 0 && canVerify()){ ?>
			<div id="verify_hide" onclick="getVerify();" class="listing_element">
				<i class="fa fa-check listing_icon success"></i><?php echo $lang['verify_account']; ?>
			</div>
			<?php } ?>
			<?php if(boomAllow(1)){ ?>
			<div onclick="getEmail();" class="listing_element">
				<i class="fa fa-envelope listing_icon default_color"></i><?php echo $lang['edit_email']; ?>
			</div>
			<?php } ?>
			<?php if(boomAllow(1)){ ?>
			<div onclick="getPassword();" class="listing_element">
				<i class="fa fa-key listing_icon theme_color"></i><?php echo $lang['change_password']; ?>
			</div>
			<?php } ?>
			<?php if(!boomAllow(11) && !userDelete($data)){ ?>
			<div id="del_account_btn" onclick="getDeleteAccount();" class="listing_element">
				<i class="fa fa-trash listing_icon error"></i><?php echo $lang['close_account']; ?>
			</div>
			<?php } ?>
		</div>
	</div>
</div>