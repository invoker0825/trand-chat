<div class="pad15">
	<?php echo listAllStatus(); ?>
</div>