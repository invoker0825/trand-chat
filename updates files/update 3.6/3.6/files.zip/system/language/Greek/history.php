<?php
$hlang['flood_mute'] = 'Σίγαση Flood';
$hlang['word_mute'] = 'Σίγαση λέξης';
$hlang['word_kick'] = 'Κλωτσιά Λέξη';
$hlang['spam_mute'] = 'Σίγαση Spam';
$hlang['spam_ban'] = 'Απαγόρευση Spam';
$hlang['mute'] = 'Σίγαση';
$hlang['ban'] = 'Απαγόρευση';
$hlang['kick'] = 'Κλωτσιά';
?>
