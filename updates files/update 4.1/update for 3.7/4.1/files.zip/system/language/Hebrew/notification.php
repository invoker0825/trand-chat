<?php
$nlang['like'] = 'הגיב לאחד מהפוסטים שלך';
$nlang['reply'] = 'הגיב על אחד מהפוסטים שלך';
$nlang['add_post'] = 'פרסם משהו על הקיר';
$nlang['accept_friend'] = 'קיבל את בקשת החברות שלך';
$nlang['word_mute'] = 'אתה הושתקת %delay% שימוש badword';
$nlang['flood_mute'] = 'החשבון שלך הושבת %delay% על הצפה';
$nlang['spam_mute'] = 'אתה הושתקת %delay% על הצפה';
$nlang['rank_change'] = 'הדרגה שלך שונתה אתה עכשיו %rank%';
$nlang['mute'] = 'הושתק בגלל %delay%';
$nlang['unmute'] = 'הוסרה ההשתקה מימך';
$nlang['name_change'] = 'שינה את השם שלך %data%';
$nlang['prolike'] = 'Has liked your profile';
$nlang['main_mute'] = 'You have been muted in main chat for %delay%';
$nlang['private_mute'] = 'You have been muted in private for %delay%';
$nlang['main_unmute'] = 'You have been unmuted in main chat';
$nlang['private_unmute'] = 'Your private has been unmuted';
$nlang['gold_share'] = 'Has shared %data% gold with you';
$nlang['gift'] = 'Has sent you a gift';
$nlang['vipgift'] = 'Has sent you a vip membership';
$nlang['vipsys'] = 'A vip membership has been added to your account';
$nlang['custom'] = '%custom%';
?>