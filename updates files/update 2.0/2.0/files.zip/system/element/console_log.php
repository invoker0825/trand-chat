<div class="sub_list_item console_data_logs" value="<?php echo $boom['id']; ?>">
	<div class="sub_list_cell">
		<p class="sub_text text_xsmall"><?php echo displayDate($boom['cdate']); ?></p> 
		<p class="text_reg"><?php echo $boom['log']; ?></p>
	</div>
</div>