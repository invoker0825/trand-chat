<?php
$hlang['flood_mute'] = 'Flodanje zabrani';
$hlang['word_mute'] = 'Loš rječnik zabrani';
$hlang['word_kick'] = 'Loš rječnik izbaci';
$hlang['spam_mute'] = 'Spamovanje zabrani';
$hlang['spam_ban'] = 'Spamovanje blokiraj';
$hlang['mute'] = 'Blokiraj konverzaciju';
$hlang['ban'] = 'Zabrani';
$hlang['kick'] = 'Izbaci';
?>