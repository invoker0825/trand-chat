<?php
require(__DIR__ . '/../config_install.php');
?>
<div class="page_element">
	<h3 class="install_h3"><i class="fa fa-check success"></i> Installation completed</h3>
	<p>Congratulation chat is successfully installed.</p><br/>
	<button id="install_done" onclick="endInstall();" type="button" class="save_admin reg_button ok_btn"><i class="fa fa-comment"></i> Go to chat</button>
</div>