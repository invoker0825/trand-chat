<?php
require('../config_session.php');

if(!canPostNews()){
	echo 0;
	die();
}
?>
<div class="modal_content">
	<div class="modal_title">
		<?php echo $lang['start_new_post']; ?>
	</div>
	<div class="post_input_container">
		<textarea onkeyup="textArea(this, 120);" id="news_data" maxlength="3000" spellcheck="false" placeholder="<?php echo $lang['type_something']; ?>" class="full_textarea" ></textarea>
		<div id="post_file_data" class="pad10 main_post_data tborder hidden" data-key="">
		</div>
		<div id="post_emo" class="post_emo_content hidden vpad5 back_box tborder">
			<?php echo listSmilies(4); ?>
		</div>
	</div>
	<div class="main_post_control">
		<div id="comment_lock" value="1" class="main_post_item" onclick="commentLock();">
			<i id="comlock" class="fa fa-commenting-o"></i>
		</div>
		<div class="bcell_mid">
		</div>
		<div class="main_post_item" onclick="showPostEmoticon();">
			<i class="fa fa-smile-o"></i>
		</div>
		<div class="main_post_item">
			<i class="fa fa-paperclip"></i>
			<input id="news_file" onchange="uploadNews();" type="file"/>
		</div>
		<div class="main_post_item" onclick="sendNews();">
			<i class="fa fa-send"></i>
		</div>
	</div>
</div>