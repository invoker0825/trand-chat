<div id="page_content">
	<div id="page_global">
		<div id="page_menu" class="page_menu menu_page">
			<div class="page_menu_wrapper">
				<?php echo $boom; ?>
			</div>
		</div>
		<div class="page_indata">
			<div id="page_wrapper">
			</div>
		</div>
	</div>
</div>
<div id="side_menu" class="hideall">
	<div class="page_menu_wrapper menu_page">
		<?php echo $boom; ?>
	</div>
</div>