<?php
$hlang['flood_mute'] = 'Flood mute';
$hlang['word_mute'] = 'Word mute';
$hlang['word_kick'] = 'Word kick';
$hlang['spam_mute'] = 'Spam mute';
$hlang['spam_ghost'] = 'Spam ghost';
$hlang['spam_ban'] = 'Spam ban';
$hlang['mute'] = 'Mute';
$hlang['ban'] = 'Ban';
$hlang['kick'] = 'Kick';
$hlang['flood_kick'] = 'Flood kick';
$hlang['vpn_kick'] = 'VPN kick';
$hlang['main_mute'] = 'Main mute';
$hlang['private_mute'] = 'Private mute';
$hlang['ghost'] = 'Ghost';
$hlang['warn'] = 'Warning';
?>