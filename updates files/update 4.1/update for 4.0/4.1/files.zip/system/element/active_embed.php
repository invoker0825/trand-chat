<div class="active_embed">
	<img alt="<?php echo $boom['user_name']; ?>" title="<?php echo $boom['user_name']; ?>" class="lazy active_embed_user" data-src="<?php echo myAvatar($boom['user_tumb']); ?>" src="<?php echo imgLoader(); ?>"/>
</div>