<?php
/**
* Codychat
*
* @package Codychat
* @author www.boomcoding.com
* @copyright 2018
* @terms any use of this script without a legal license is prohibited
* all the content of Codychat is the propriety of BoomCoding and Cannot be 
* used for another project.
*/
require_once('../config_session.php');
?>
<div class="panel_wrap boom_keep">
	<?php echo getNews(); ?>
</div>