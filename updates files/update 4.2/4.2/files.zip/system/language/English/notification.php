<?php
$nlang['like'] = 'has reacted to one of your posts';
$nlang['reply'] = 'commented on one of your posts';
$nlang['add_post'] = 'posted something on the wall';
$nlang['accept_friend'] = 'has accepted your friend request';
$nlang['word_mute'] = 'You have been muted for %delay% for using prohibited words';
$nlang['flood_mute'] = 'You have been muted for %delay% for flooding';
$nlang['spam_mute'] = 'You have been muted for %delay% for spamming';
$nlang['rank_change'] = 'Your rank has been changed to %rank%';
$nlang['mute'] = 'You have been muted for %delay%';
$nlang['unmute'] = 'You have been unmuted';
$nlang['name_change'] = 'has changed your username to %data%';
$nlang['prolike'] = 'has liked your profile';
$nlang['main_mute'] = 'You have been muted in main chat for %delay%';
$nlang['private_mute'] = 'You have been muted in private chats for %delay%';
$nlang['main_unmute'] = 'You have been unmuted in main chat';
$nlang['private_unmute'] = 'You have been unmuted in private chats';
$nlang['gold_share'] = 'has shared %data% gold with you';
$nlang['gift'] = 'has sent you a gift';
$nlang['vipgift'] = 'has sent you a VIP membership';
$nlang['vipsys'] = 'A VIP membership has been added to your account';
$nlang['custom'] = '%custom%';
?>