<?php
require('../config.php');
?>
<div class="pad_box text_box">
	<?php echo loadPageData('privacy_policy'); ?>
</div>