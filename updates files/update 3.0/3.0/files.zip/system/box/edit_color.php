<?php
require('../config_session.php');
if(!canNameColor()){
	die();
}
?>
<div class="pad20">
	<div class="user_edit_color">
		<div class="my_name_color" data="<?php echo $data['user_color']; ?>">
			<?php if(canNameGrad()){ ?>
			<div class="reg_menu_container tmargin10">		
				<div class="reg_menu">
					<ul>
						<li class="reg_menu_item reg_selected" data="color_tab" data-z="reg_color"><?php echo $lang['color']; ?></li>
						<li class="reg_menu_item" data="color_tab" data-z="grad_color"><?php echo $lang['gradient']; ?></li>
					</ul>
				</div>
			</div>
			<?php } ?>
			<div id="color_tab">
				<div id="reg_color" class="reg_zone vpad5">
					<?php echo colorChoice($data['user_color'], 3); ?>
					<div class="clear"></div>
				</div>
				<?php if(canNameGrad()){ ?>
				<div id="grad_color" class="reg_zone vpad5 hide_zone">
					<?php echo gradChoice($data['user_color'], 3); ?>
					<div class="clear"></div>
				</div>
				<?php } ?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</div>