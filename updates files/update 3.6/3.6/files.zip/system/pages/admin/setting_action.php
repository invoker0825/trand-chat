<?php
require_once('../../config_version.php');
require('encoded/' . $boom_version . '/' . basename(__FILE__));
?>