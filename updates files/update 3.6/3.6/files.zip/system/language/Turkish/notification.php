<?php
$nlang['like'] = 'Paylaşımlarınızdan birine beğeni yapıldı.';
$nlang['reply'] = 'Paylaşımınıza yorum yapıldı';
$nlang['add_post'] = 'Arkadaş duvarınıza bir paylaşım yapıldı';
$nlang['accept_friend'] = 'Gönderdiğiniz arkadaşlık isteği kabul edildi.';
$nlang['word_mute'] = 'Sessizleştirildiniz %delay% kötü kelime nedeni ile.';
$nlang['flood_mute'] = 'Sessizleştirildiniz %delay% flod nedeni ile.';
$nlang['spam_mute'] = 'Sessizleştirildiniz %delay% spam mesaj nedeni ile.';
$nlang['rank_change'] = 'Seviyeniz değiştirildi. Yeni seviyeniz %rank%';
$nlang['mute'] = 'Sessizleştirildiniz %delay% ';
$nlang['unmute'] = 'Sessizlik engeliniz kaldırıldı.';
$nlang['name_change'] = 'Kullanıc adınız değiştrildi. Yeni kullanıcı adı %data%';
?>