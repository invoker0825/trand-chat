<?php
$nlang['like'] = 'A réagit à une de vos publications';
$nlang['reply'] = 'A commenté sur une de vos publications';
$nlang['add_post'] = 'A publié quelque chose sur le mur';
$nlang['accept_friend'] = 'A acceptée votre demande amis';
$nlang['word_mute'] = 'Vous avez été mis en silence %delay% pour language abusif';
$nlang['flood_mute'] = 'Votre compte a été mis en silence %delay% pour flood';
$nlang['spam_mute'] = 'Vous avez été mis en silence %delay% pour spam';
$nlang['rank_change'] = 'Votre rank a changé vous êtes maintenant %rank%';
$nlang['mute'] = 'Vous avez été mis en silence pour %delay%';
$nlang['unmute'] = 'Votre silence a été enlever';
$nlang['name_change'] = 'A changer votre pseudo par %data%';
?>