<option <?php echo selCurrent($boom, ''); ?> value="">Normal</option>
<option <?php echo selCurrent($boom, 'bold'); ?> value="bold">Bold</option>
<option <?php echo selCurrent($boom, 'heavybold'); ?> value="heavybold">Heavy</option>
<option <?php echo selCurrent($boom, 'ital'); ?> value="ital">Italic</option>
<option <?php echo selCurrent($boom, 'boldital'); ?> value="boldital">Bold italic</option>
<option <?php echo selCurrent($boom, 'heavyital'); ?> value="heavyital">Heavy italic</option>