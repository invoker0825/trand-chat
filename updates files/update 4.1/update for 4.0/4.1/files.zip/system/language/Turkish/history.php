<?php
$hlang['flood_mute'] = 'Flood susturması';
$hlang['word_mute'] = 'Genel susturma';
$hlang['word_kick'] = 'Genel Tekme';
$hlang['spam_mute'] = 'Spam susturması';
$hlang['spam_ghost'] = 'Spam ghost';
$hlang['spam_ban'] = 'Spam yasağı';
$hlang['mute'] = 'Sustur';
$hlang['ban'] = 'Yasakla';
$hlang['kick'] = 'Tekmele';
$hlang['flood_kick'] = 'Flood kick';
$hlang['vpn_kick'] = 'Vpn kick';
$hlang['main_mute'] = 'Genel susturma';
$hlang['private_mute'] = 'Özel susturma';
$hlang['ghost'] = 'Hayalet';
?>