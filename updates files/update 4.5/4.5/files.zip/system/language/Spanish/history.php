<?php
$hlang['flood_mute'] = 'Silenciado por atiborramiento';
$hlang['word_mute'] = 'Silenciado por ofensivo';
$hlang['word_kick'] = 'Expulsado por ofensivo';
$hlang['spam_mute'] = 'Silenciado por spam';
$hlang['spam_ghost'] = 'Spam ghost';
$hlang['spam_ban'] = 'Baneado por spam';
$hlang['mute'] = 'Silenciado';
$hlang['ban'] = 'Baneado';
$hlang['kick'] = 'Expulsado';
$hlang['flood_kick'] = 'Expulsión por inundación';
$hlang['vpn_kick'] = 'Expulsión por Vpn';
$hlang['main_mute'] = 'Silencio principal';
$hlang['private_mute'] = 'Silencio privado';
$hlang['ghost'] = 'Modo fantasma';
$hlang['warn'] = 'Warning';
?>