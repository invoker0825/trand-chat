<?php
$nlang['like'] = 'Ha reaccionado a una de tus publicaciones';
$nlang['reply'] = 'Comentó en una de tus publicaciones';
$nlang['add_post'] = 'Publicó algo en el muro';
$nlang['accept_friend'] = 'Aceptó tu solicitud de amistad';
$nlang['word_mute'] = 'Has sido silenciado %delay% por usar lenguaje ofensivo';
$nlang['flood_mute'] = 'Tu cuenta ha sido silenciada %delay% por haber llenado el chat de mensajes';
$nlang['spam_mute'] = 'Has sido silenciado %delay% por mandar mensajes no deseados';
$nlang['rank_change'] = 'Tu rango ha cambiado. Ahora eres %rank%';
$nlang['mute'] = 'Has sido silenciado %delay%';
$nlang['unmute'] = 'Has sido desilenciado';
$nlang['name_change'] = 'Has cambiado tu nombre de usuario a %data%';
$nlang['prolike'] = 'Le ha gustado tu perfil';
$nlang['main_mute'] = 'Has sido silenciado/a en el chat principal por %delay%';
$nlang['private_mute'] = 'Has sido silenciado/a en el chat privado por %delay%';
$nlang['main_unmute'] = 'Has sido desilenciado/a en el chat principal';
$nlang['private_unmute'] = 'Has sido desilenciado/a en el chat privado';
$nlang['gold_share'] = 'Ha compartido %data% de oro contigo';
$nlang['gift'] = 'Te ha enviado un regalo';
$nlang['vipgift'] = 'Te ha enviado una membresía vip';
$nlang['vipsys'] = 'Una membresía vip ha sido añadida a tu cuenta';
$nlang['custom'] = '%custom%';
?>