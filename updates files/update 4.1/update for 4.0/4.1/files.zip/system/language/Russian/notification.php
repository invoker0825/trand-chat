<?php
$nlang['like'] = 'Оценил Ваш пост';
$nlang['reply'] = 'Прокомментировал Ваш пост';
$nlang['add_post'] = 'Разместил что-то на стене';
$nlang['accept_friend'] = 'Принял ваш запрос на добавление в друзья';
$nlang['word_mute'] = 'Вы получили кляп на %delay% за мат';
$nlang['flood_mute'] = 'Вы получили кляп на %delay% за флуд';
$nlang['spam_mute'] = 'Вы получили кляп на %delay% за спам';
$nlang['rank_change'] = 'Ваш ранг был изменен на %rank%';
$nlang['mute'] = 'Вы получили кляп на %delay%';
$nlang['unmute'] = 'С Вас сняли кляп';
$nlang['name_change'] = 'Ваш ник был изменен на %data%';
$nlang['prolike'] = 'понравился ваш профиль';
$nlang['main_mute'] = 'Вы были отключены в основном чате на %delay%';
$nlang['private_mute'] = 'Вы были отключены в привате на %delay%';
$nlang['main_unmute'] = 'Ваш звук в основном чате включен';
$nlang['private_unmute'] = 'Ваш личный был включен';
$nlang['gold_share'] = 'Поделился %data% золото с тобой';
$nlang['gift'] = 'отправил вам подарок';
$nlang['vipgift'] = 'Отправил вам VIP-членство';
$nlang['vipsys'] = 'К вашему аккаунту добавлено VIP-членство';
$nlang['custom'] = '%custom%';
?>