<div class="pad15">
	<textarea class="full_textarea xlarge_textarea" type="text"><?php echo stripslashes($boom['news_message']); ?></textarea>
	<div class="tpad10">
		<button class="reg_button theme_btn"><?php echo $lang['save']; ?></button>
	</div>
</div>