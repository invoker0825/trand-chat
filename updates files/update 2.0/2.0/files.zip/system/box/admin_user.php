<?php 
require('../config_session.php');
if(!isset($_POST['edit_user']) || !boomAllow(9)){
	die();
}
$result = '';
$target = escape($_POST['edit_user']);
$user = userDetails($target);
if(!isGreater($user['user_rank']) && notMe($user['user_id'])){
	echo 99;
	die();
}
if(isBot($user['user_bot']) && !boomAllow(11)){
	echo 99;
	die();
}

?>
<div class="modal_wrap_top modal_top">
	<div class="btable profile_top">
		<div class="profile_avatar" data="<?php echo $user['user_tumb']; ?>" >
			<div class="avatar_spin">
				<img class="fancybox avatar_profile" <?php echo profileAvatar($user['user_tumb']); ?>/>
			</div>
			<?php 
			if(canModifyAvatar($user)){ ?>
			<div class="avatar_control olay">
				<div class="button full_button avatar_button" onclick="adminRemoveAvatar(<?php echo $user['user_id']; ?>);">
					<i class="fa fa-times"></i>
				</div>
				<div id="avatarupload" class="avatar_button">
					<form id="admin_avatar_form" action="system/avatar_admin.php" method="post" enctype="multipart/form-data">
						<div class="button choose_avatar full_button">
							<span><i class="fa fa-camera"></i></span>
							<input class="upload avatar_select" type="file" name="file" id="admin_avatar_image">
						</div>
						<input type="hidden" value="<?php echo setToken(); ?>" name="token">
						<input id="this_admin_avatar" type="hidden" value="<?php echo $user['user_id']; ?>" name="avatar_target">
					</form>
				</div>
			</div>
			<?php } ?>
		</div>
		<div class="profile_tinfo">
			<div class="pdetails">
				<?php if(boomAllow($data['allow_name']) && canEditUser($user, 9)){ ?> 
				<div class="pdetails_icon text_med bold" onclick="adminChangeName(<?php echo $user['user_id']; ?>);">
					<i  class="fa fa-pencil"></i>
				</div>
				<?php } ?>
				<div id="pro_admin_name" class="pdetails_text pro_name">
					<?php echo $user['user_name']; ?>
				</div>
			</div>
			<?php if(boomAllow($data['allow_mood']) && canEditUser($user, 9)){ ?>
			<div class="pdetails sub_dark">
				<div class="pdetails_icon text_med bclick" onclick="adminChangeMood(<?php echo $user['user_id']; ?>);">
					<i  class="fa fa-pencil"></i>
				</div>
				<div id="pro_admin_mood" class="pdetails_text pro_mood bellips">
					<?php echo getMood($user); ?>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
	<div class="cancel_modal profile_close">
		<i class="fa fa-times"></i>
	</div>
</div>
<div class="modal_menu">
	<ul>
		<li class="modal_menu_item modal_selected" data="admin_pro_details"><?php echo $lang['options']; ?></li>
		<?php if(!isBot($user['user_bot'])){ ?>
		<li class="modal_menu_item" data="admin_pro_email"><?php echo $lang['email']; ?></li>
		<?php } ?>
		<li class="modal_menu_item" data="void" onclick="getProfile(<?php echo $user['user_id']; ?>);"><?php echo $lang['back']; ?></li>
	</ul>
</div>
<div class="modal_zone pad25" id="admin_pro_details">
	<?php if(!isGuest($user['user_rank'])){ ?>
	<div class="bmargin15">
		<div class="">
			<p class="label"><?php echo $lang['user_rank']; ?></p>
			<select id="profile_rank" onchange="changeRank(this, <?php echo $user['user_id']; ?>);">
				<?php echo changeRank($user['user_rank']); ?>
			</select>
		</div>
		<div class="clear"></div>
	</div>
	<?php } ?>
	<?php if(canNameColor()){ ?>
	<div>
		<p class="label"><?php echo $lang['user_color']; ?></p>
		<div class="user_color" data-u="<?php echo $user['user_id']; ?>" data="<?php echo $user['user_color']; ?>">
			<?php if(canNameGrad()){ ?>
			<div class="reg_menu_container tmargin10">		
				<div class="reg_menu">
					<ul>
						<li class="reg_menu_item reg_selected" data="color_tab" data-z="reg_color"><?php echo $lang['color']; ?></li>
						<li class="reg_menu_item" data="color_tab" data-z="grad_color"><?php echo $lang['gradient']; ?></li>
					</ul>
				</div>
			</div>
			<?php } ?>
			<div id="color_tab">
				<div id="reg_color" class="reg_zone vpad5">
					<?php echo colorChoice($user['user_color'], 1); ?>
					<div class="clear"></div>
				</div>
				<?php if(canNameGrad()){ ?>
				<div id="grad_color" class="reg_zone vpad5 hide_zone">
					<?php echo gradChoice($user['user_color'], 1); ?>
					<div class="clear"></div>
				</div>
				<?php } ?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<?php } ?>
</div>
<div class="modal_zone  pad25 tpad15 hide_zone" id="admin_pro_email">
	<div class="boom_form">
		<div class="setting_element">
			<p class="label"><?php echo $lang['email']; ?></p>
			<input id="set_user_email" class="full_input" value="<?php echo $user['user_email']; ?>" type="text"/>
		</div>
	</div>
	<button onclick="saveThisUser(<?php echo $user['user_id']; ?>);" type="button" class="save_admin reg_button theme_btn"><?php echo $lang['save']; ?></button>
</div>