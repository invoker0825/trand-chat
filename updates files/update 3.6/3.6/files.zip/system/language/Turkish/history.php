<?php
$hlang['flood_mute'] = 'Flood susturması';
$hlang['word_mute'] = 'Genel susturma';
$hlang['word_kick'] = 'Genel Tekme';
$hlang['spam_mute'] = 'Spam susturması';
$hlang['spam_ban'] = 'Spam yasağı';
$hlang['mute'] = 'Sustur';
$hlang['ban'] = 'Yasakla';
$hlang['kick'] = 'Tekmele';
?>