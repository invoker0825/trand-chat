<div class="empty_zone">
	<img class="empty_zone_icon" src="<?php echo $data['domain']; ?>/default_images/icons/<?php echo $boom['icon']; ?>"/>
	<p class="empty_zone_text sub_text"><?php echo $boom['text']; ?></p>
</div>