<?php
$nlang['like'] = 'وجد رد فعل على واحدة من مشاركتك';
$nlang['reply'] = 'علق على واحدة من مشاركتك';
$nlang['add_post'] = 'نشر شيء على الحائط';
$nlang['accept_friend'] = 'قبلت طلب صديقك';
$nlang['word_mute'] = 'لقد تم كتم المستخدم %delay% بسبب كلمة سيئة';
$nlang['flood_mute'] = 'تم كتم حسابك %delay% بسبب الفيضانات';
$nlang['spam_mute'] = 'لقد تم كتم حساب %delay%  بسبب الرسائل غير المرغوب فيها';
$nlang['rank_change'] = 'تم تغيير رتبتك أنت الآن %rank%';
$nlang['mute'] = 'لقد تم كتم حساب %delay%';
$nlang['unmute'] = 'لقد تم إلغاء كتم';
$nlang['name_change'] = 'تم تغيير اسم المستخدم الخاص بك لـ %data%';
?>