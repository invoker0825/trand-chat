<?php
$nlang['like'] = 'Оценил Ваш пост';
$nlang['reply'] = 'Прокомментировал Ваш пост';
$nlang['add_post'] = 'Разместил что-то на стене';
$nlang['accept_friend'] = 'Принял ваш запрос на добавление в друзья';
$nlang['word_mute'] = 'Вы получили кляп на %delay% за мат';
$nlang['flood_mute'] = 'Вы получили кляп на %delay% за флуд';
$nlang['spam_mute'] = 'Вы получили кляп на %delay% за спам';
$nlang['rank_change'] = 'Ваш ранг был изменен на %rank%';
$nlang['mute'] = 'Вы получили кляп на %delay%';
$nlang['unmute'] = 'С Вас сняли кляп';
$nlang['name_change'] = 'Ваш ник был изменен на %data%';
?>