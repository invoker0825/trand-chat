<div class="user_square_elem get_info" data="<?php echo $boom['user_id']; ?>">
	<img data-img="<?php echo myavatar($boom['user_tumb']); ?>" class="avatar_friends lazyboom" src=""/>
	<div class="olay user_square_name">
		<?php echo $boom['user_name']; ?>
	</div>
</div>